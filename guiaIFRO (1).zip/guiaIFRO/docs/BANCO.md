# Banco de dados do Guia IFRO

MariaDB/MySQL, `utf8mb4`. Criado por `sql/schema.sql` e preenchido por `sql/seed.php`
(o jeito fácil é rodar `bin/instalar-banco.php`, ver README).

## Modelo principal: categoria → setor → sala

```
categorias (grupo do organograma)          andares
  id (slug) PK                               id (slug) PK  'terreo', 'andar1'
  nome, icone, cor, ordem                    nome, ordem
      │ 1                                        │ 1
      │                                          │
      │ N                                        │ N
setores ─────────────────────────────1:N────── salas
  id (slug) PK  'cra', 'biblioteca'...          id (slug) PK
  categoria_id FK                               andar_id FK, ala, ordem, lado, ponta
  nome, sigla, icone, cor                       nome, nome_curto, funcao
  descricao, descricao_curta                    setor_id FK (NULL = sala sem setor: banheiro, copa...)
  localizacao, bloco, sala_texto
  telefone, email, responsavel, video
  horario_texto (só observação)
  ativo, atualizado_em, atualizado_por
      │
      ├── setor_equipe      (setor_id, nome, cargo, ordem)
      ├── setor_servicos    (setor_id, nome, ordem)
      ├── setor_documentos  (setor_id, nome, arquivo, ordem)
      ├── setor_horarios    (setor_id, dia_semana 0-6, abre, fecha, observacao)
      ├── setor_excecoes    (setor_id NULL = campus todo, data, fechado, abre, fecha, motivo)
      ├── sinonimos         (setor_id, nome)  palavras que a busca também aceita
      ├── faq_setor ── faq  (N:N; FAQ sem setor = FAQ geral)
      └── usuario_setor ── usuarios ── perfis

pecas_mapa (cenário do mapa: bloco, obra, quadra, estacionamento, área verde, árvore)
  id, tipo, nome, x, z, largura, profundidade, rotacao, inicio, fim
acessibilidade_sala (sala_id: rampa, elevador, banheiro adaptado... 1 = tem, 0 = não, NULL = não informado)
```

## Conteúdo

```
avisos           titulo, mensagem, nivel (normal/urgente), inicio, fim, publicado
noticias         slug, titulo, resumo, conteudo, categoria, publicada_em, destaque, publicado
eventos          titulo, descricao, inicio, fim, tipo (evento/feriado/recesso/letivo), periodo_letivo, publicado
links_uteis      titulo, url, ordem, publicado
textos_institucionais  titulo, conteudo, ordem, publicado
atalhos_home     titulo, descricao, icone, cor, url, ordem
configuracoes    chave PK, valor  (contato geral, redes sociais, link do WhatsApp...)
fluxos           "Como faço para...": slug, titulo, setor_id, prazo, publicado
  ├── fluxo_passos      (fluxo_id, texto, ordem)
  └── fluxo_documentos  (fluxo_id, nome, ordem)
```

## Usuários, segurança e registros

```
perfis           id (slug) 'admin_geral', 'responsavel_setor'
usuarios         nome, usuario, email, senha_hash, perfil_id, ativo, sessao_versao, ultimo_login_em
usuario_setor    usuario_id, setor_id   (quais setores o responsável pode editar)
limites          acao, chave_hash, criado_em   (limite de envios/tentativas; IP guardado só como hash)
auditoria        usuario_id, usuario_nome, acao, tabela, registro_id, antes, depois, quando
contatos_mensagens  nome, email, telefone, assunto, mensagem, criada_em, lida_em
```

## Regras

- O site só fala com o banco por `model/Repositorio.php` (PDO + prepared statements).
- O usuário do banco usado pelo site (`config/banco.php`) só tem SELECT/INSERT/UPDATE/DELETE
  no banco `guia_ifro`. Nunca usar root no site.
- Toda alteração feita pelo admin vai para `auditoria` (antes/depois em JSON).
