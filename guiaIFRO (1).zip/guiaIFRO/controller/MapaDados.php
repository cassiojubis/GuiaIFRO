<?php
/**
 * DADOS DO MAPA INTERATIVO — usados pela página do mapa (mapa.php) e pela home (index.php),
 * que mostram o mesmo mapa (view/parciais/mapa-interativo.php).
 *
 * ?sala=<id> já abre com a sala selecionada e ?de=<id> diz de onde a rota sai
 * ("Estou aqui" / QR da porta). Sala que não existe é ignorada.
 */

/** Devolve tudo que a parcial do mapa precisa: salas por andar, sala pedida e o JSON do JavaScript. */
function prepararMapa(): array
{
    $mapa = listarMapaSalas();

    // Mesmo filtro do setor.php: só letras, números, _ e -.
    $idSalaPedida = isset($_GET['sala']) ? preg_replace('/[^a-z0-9_-]/i', '', (string) $_GET['sala']) : '';
    $salaInicial = $idSalaPedida !== '' ? buscarSalaDoMapa($idSalaPedida) : null;

    $idOrigemPedida = isset($_GET['de']) ? preg_replace('/[^a-z0-9_-]/i', '', (string) $_GET['de']) : '';
    $origemInicial = $idOrigemPedida === 'entrada' ? 'entrada' : (($idOrigemPedida !== '' && buscarSalaDoMapa($idOrigemPedida)) ? $idOrigemPedida : null);

    // Separa as salas por andar para montar a lista lateral já no PHP
    // (assim a lista existe mesmo antes do JavaScript carregar).
    $salasPorAndar = [];
    foreach ($mapa['salas'] as $sala) {
        $salasPorAndar[$sala['andar']][] = $sala;
    }

    // Tudo que o JavaScript precisa, entregue de uma vez como JSON.
    $dadosMapaJson = json_encode([
        'andares' => $mapa['andares'],
        'salas' => $mapa['salas'],
        'pecas' => listarPecasMapa(), // cenário (bloco, quadra, obra...) que vale agora
        'salaInicial' => $salaInicial['id'] ?? null,
        'origemInicial' => $origemInicial,
        'semEscada' => salasSemEscada(), // I3: sala_id => chega sem escada? (térreo ou elevador informado)
        'velocidadeCaminhada' => (float) str_replace(',', '.', configuracao('velocidade_caminhada', '1.2')),
        'scripts3d' => scriptsDoMapa3d(),
    ], JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP);

    return [
        'mapa' => $mapa,
        'salasPorAndar' => $salasPorAndar,
        'idSalaPedida' => $idSalaPedida,
        'salaNaoEncontrada' => $idSalaPedida !== '' && $salaInicial === null,
        'dadosMapaJson' => $dadosMapaJson,
    ];
}

/**
 * Arquivos do mapa 3D. Eles só são baixados quando alguém clica em "Ver em 3D".
 * Se a pasta js/vendor/three/ tiver os três arquivos, usa a cópia local (funciona
 * sem internet); senão, usa o CDN jsDelivr com a mesma versão (r128).
 */
function scriptsDoMapa3d(): array
{
    $pastaVendor = __DIR__ . '/../js/vendor/three/';
    $arquivosThree = ['three.min.js', 'OrbitControls.js', 'CSS2DRenderer.js'];
    $temThreeLocal = true;
    foreach ($arquivosThree as $arquivo) {
        if (!is_file($pastaVendor . $arquivo)) {
            $temThreeLocal = false;
        }
    }
    $scripts = $temThreeLocal
        ? array_map(static function ($arquivo) { return 'js/vendor/three/' . $arquivo; }, $arquivosThree)
        : [
            'https://cdn.jsdelivr.net/npm/three@0.128.0/build/three.min.js',
            'https://cdn.jsdelivr.net/npm/three@0.128.0/examples/js/controls/OrbitControls.js',
            'https://cdn.jsdelivr.net/npm/three@0.128.0/examples/js/renderers/CSS2DRenderer.js',
        ];
    // por último, o nosso próprio código do 3D (com ?v= para o navegador não usar versão velha)
    $scripts[] = 'js/mapa3d.js?v=' . filemtime(__DIR__ . '/../js/mapa3d.js');
    return $scripts;
}
