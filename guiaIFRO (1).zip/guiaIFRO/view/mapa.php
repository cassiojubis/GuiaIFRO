<?php
// O CSS do mapa só é carregado nesta página (ver parciais/cabecalho.php)
$estilosExtras = ['css/mapa.css'];
require __DIR__ . '/parciais/cabecalho.php';
?>

<section class="page-header light-header compact-header">
    <div class="container reveal">
        <nav class="breadcrumb">
            <a href="index.php">Início</a>
            <?= icone('chevron-right') ?>
            <strong>Mapa Interativo</strong>
        </nav>
        <h1>Mapa do Campus</h1>
        <p>Escolha um setor na lista ou clique numa sala para ver o caminho desde o portão, passo a passo.</p>
        <p class="mapa-texto-link"><?= icone('list') ?> Prefere sem desenho (leitor de tela, celular simples)? <a href="mapa-texto.php">Veja o mapa em texto</a>.</p>
    </div>
</section>

<section class="section container mapa-secao">
    <?php if ($dadosMapa['salaNaoEncontrada']): ?>
        <p class="aviso-faixa" role="alert"><?= icone('triangle-alert') ?> <span>Não encontramos a sala <strong><?= htmlspecialchars($dadosMapa['idSalaPedida'], ENT_QUOTES, 'UTF-8') ?></strong>. Escolha o destino na lista do mapa.</span></p>
    <?php endif; ?>
    <?php require __DIR__ . '/parciais/mapa-interativo.php'; ?>
</section>

<?php require __DIR__ . '/parciais/rodape.php'; ?>
