<?php
/**
 * MAPA INTERATIVO (2D + 3D opcional), o mesmo na página do mapa e na home.
 * Quem inclui já chamou prepararMapa() (controller/MapaDados.php) e guardou em $dadosMapa.
 * O css/mapa.css precisa estar em $estilosExtras.
 */
$mapa = $dadosMapa['mapa'];
$salasPorAndar = $dadosMapa['salasPorAndar'];
?>
    <!-- Seletor 2D / 3D: os dois mapas dividem o mesmo espaço, a lista e o cartão -->
    <div class="mapa-barra">
        <div class="mapa-modo" role="group" aria-label="Tipo de mapa">
            <button type="button" data-modo="2d" aria-pressed="true"><?= icone('map') ?> Planta 2D</button>
            <button type="button" data-modo="3d" aria-pressed="false"><?= icone('box') ?> Ver em 3D</button>
        </div>
        <button type="button" class="button button-outline button-small" id="mapa-passeio-iniciar"><?= icone('clapperboard') ?> Passeio pelo prédio (3D)</button>
        <p class="mapa-barra-texto">O 3D é opcional e só é baixado quando você clica nele.</p>
    </div>

    <div class="mapa-palco" id="mapa-palco" data-modo="2d">
        <!-- MAPA 2D (principal): desenhado em SVG pelo js/mapa2d.js -->
        <svg id="mapa2d" class="mapa2d" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid meet" role="group" tabindex="0"
            aria-label="Planta do prédio em 2D. Use Tab para passar pelas salas e Enter para escolher. Setas movem a planta, + e - aproximam."
            aria-describedby="mapa-descricao"></svg>
        <p id="mapa-descricao" class="visually-hidden">O prédio tem uma entrada no meio, uma escada central e duas alas: a esquerda e a direita de quem entra. O mesmo conteúdo está no mapa em texto.</p>

        <!-- MAPA 3D (opcional): o js/mapa3d.js e o three.js só entram aqui depois do clique -->
        <div id="mapa3d" class="mapa3d" hidden role="region" aria-label="Maquete 3D do prédio" aria-describedby="mapa3d-descricao" tabindex="-1"></div>
        <p id="mapa3d-descricao" class="visually-hidden">Maquete do prédio em 3D, igual à planta 2D. Para escolher uma sala pelo teclado, use a lista de setores. Esc ou o botão "Voltar para a planta 2D" fecham o 3D.</p>
        <!-- Passeio pelo 3D (W1): legenda + controles -->
        <div class="mapa-passeio" id="mapa-passeio" hidden role="region" aria-label="Passeio pelo prédio">
            <p class="mapa-passeio-texto" id="mapa-passeio-texto" aria-live="polite"></p>
            <div class="mapa-passeio-botoes">
                <small id="mapa-passeio-contador"></small>
                <button type="button" id="mapa-passeio-pausar">Pausar</button>
                <button type="button" id="mapa-passeio-pular">Pular</button>
                <button type="button" id="mapa-passeio-sair">Sair do passeio</button>
            </div>
        </div>
        <button type="button" class="mapa-voltar-2d" id="mapa-voltar-2d" hidden><?= icone('map') ?> Voltar para a planta 2D</button>
        <div class="mapa-carregando" id="mapa-carregando" hidden>
            <span class="mapa-carregando-roda" aria-hidden="true"></span> Carregando o mapa 3D…
        </div>

        <!-- LISTA DE SETORES (a mesma para os dois mapas) -->
        <div class="mapa-painel mapa-lista" id="mapa-lista">
            <!-- De onde a rota sai (N2): portão, entrada ou uma sala ("Estou aqui" / QR da porta) -->
            <label class="mapa-origem">
                <span>Saindo de</span>
                <select id="mapa-origem">
                    <option value="">Portão do campus</option>
                    <option value="entrada">Entrada do prédio</option>
                    <?php foreach ($mapa['andares'] as $idAndar => $andar): ?>
                        <?php if (empty($salasPorAndar[$idAndar])) continue; ?>
                        <optgroup label="<?= htmlspecialchars($andar['nome'], ENT_QUOTES, 'UTF-8') ?>">
                            <?php foreach ($salasPorAndar[$idAndar] as $sala): ?>
                                <option value="<?= htmlspecialchars($sala['id'], ENT_QUOTES, 'UTF-8') ?>"><?= htmlspecialchars($sala['nome'], ENT_QUOTES, 'UTF-8') ?></option>
                            <?php endforeach; ?>
                        </optgroup>
                    <?php endforeach; ?>
                </select>
            </label>
            <label class="mapa-busca">
                <?= icone('search') ?>
                <span class="sr-only">Buscar setor ou sala</span>
                <input id="mapa-busca" type="search" placeholder="Buscar setor ou sala…" autocomplete="off">
            </label>
            <div class="mapa-lista-salas" id="mapa-lista-salas">
                <?php foreach ($mapa['andares'] as $idAndar => $andar): ?>
                    <?php if (empty($salasPorAndar[$idAndar])) continue; ?>
                    <div class="mapa-lista-grupo" data-grupo="<?= htmlspecialchars($idAndar) ?>">
                        <h3><?= htmlspecialchars($andar['nome']) ?></h3>
                        <?php foreach ($salasPorAndar[$idAndar] as $sala): ?>
                            <button type="button" class="mapa-lista-item <?= htmlspecialchars($sala['ala']) ?>" data-sala="<?= htmlspecialchars($sala['id']) ?>" aria-pressed="false">
                                <i aria-hidden="true"></i><span><?= htmlspecialchars($sala['nome']) ?></span>
                            </button>
                        <?php endforeach; ?>
                    </div>
                <?php endforeach; ?>
            </div>
            <p class="mapa-lista-vazia" id="mapa-lista-vazia" hidden>Nenhum setor encontrado.</p>
        </div>

        <!-- ANDARES E FERRAMENTAS (canto direito) -->
        <div class="mapa-controles">
            <div class="mapa-painel mapa-andares" role="group" aria-label="Andar">
                <button type="button" data-andar="todos" aria-pressed="false" hidden>Os dois</button>
                <?php foreach ($mapa['andares'] as $idAndar => $andar): ?>
                    <button type="button" data-andar="<?= htmlspecialchars($idAndar) ?>" aria-pressed="<?= $idAndar === 'terreo' ? 'true' : 'false' ?>"><?= htmlspecialchars($andar['nome']) ?></button>
                <?php endforeach; ?>
            </div>
            <div class="mapa-painel mapa-ferramentas">
                <button type="button" data-acao="aproximar" data-so="2d" title="Aproximar" aria-label="Aproximar"><?= icone('plus') ?></button>
                <button type="button" data-acao="afastar" data-so="2d" title="Afastar" aria-label="Afastar"><?= icone('minus') ?></button>
                <button type="button" data-acao="girar" data-so="3d" title="Girar automaticamente" aria-label="Girar automaticamente" aria-pressed="false" hidden><?= icone('rotate-cw') ?></button>
                <button type="button" data-acao="visaoGeral" title="Visão geral" aria-label="Visão geral"><?= icone('house') ?></button>
            </div>
        </div>

        <!-- CARTÃO DA SALA (o mesmo para os dois mapas), preenchido pelo js/mapa.js -->
        <section class="mapa-painel mapa-info" id="mapa-info" aria-labelledby="mapa-info-nome" aria-hidden="true">
            <button type="button" class="mapa-info-fechar" id="mapa-info-fechar" aria-label="Fechar">&times;</button>
            <p class="mapa-info-andar" id="mapa-info-andar"></p>
            <h2 id="mapa-info-nome"></h2>
            <div class="mapa-chips" id="mapa-info-chips"></div>
            <ol class="mapa-passos" id="mapa-info-passos"></ol>
            <button type="button" class="button button-outline button-small mapa-ouvir" data-ouvir="#mapa-info-passos"><span aria-hidden="true">🔊</span> Ouvir o caminho</button>
            <p class="mapa-aviso-escada" id="mapa-info-escada" hidden><?= icone('triangle-alert') ?> <span>Este andar só tem acesso cadastrado pela escada. Precisa evitar escada? Peça atendimento no térreo ou fale com o <a href="setor.php?id=napne">NAPNE</a>.</span></p>
            <button type="button" class="button button-outline button-full mapa-estou-aqui" id="mapa-estou-aqui"><?= icone('locate-fixed') ?> Estou aqui: sair desta sala</button>
            <button type="button" class="mapa-info-trecho" id="mapa-info-trecho" hidden></button>
            <a href="#" class="button button-primary button-full mapa-info-setor" id="mapa-info-setor" hidden>
                <span id="mapa-info-setor-texto">Ver página do setor</span> <?= icone('arrow-right') ?>
            </a>
        </section>

        <button type="button" class="mapa-abrir-lista" id="mapa-abrir-lista" aria-controls="mapa-lista" aria-expanded="false">
            <?= icone('list') ?> Setores
        </button>
        <div class="mapa-dica" id="mapa-dica" aria-hidden="true">arraste para mover · role para zoom · clique numa sala</div>
        <div class="mapa-aviso" id="mapa-aviso" role="status" aria-live="polite"></div>

        <noscript>
            <p class="mapa-sem-js">O desenho do mapa precisa de JavaScript. A lista de salas ao lado continua disponível.</p>
        </noscript>
    </div>

<!-- Dados do mapa para o JavaScript (mesmo padrão do #setores-busca-data do cabeçalho).
     As flags JSON_HEX_* trocam < > & por códigos, então nenhum nome consegue "fechar" esta tag. -->
<script type="application/json" id="mapa-dados"><?= $dadosMapa['dadosMapaJson'] ?></script>
<!-- Ordem importa: o grafo.js calcula a rota (Dijkstra), o mapa2d.js só define o desenho e o mapa.js liga tudo. O 3D é carregado depois, sob demanda. -->
<script src="js/grafo.js?v=<?= filemtime(__DIR__ . '/../../js/grafo.js') ?>" defer></script>
<script src="js/mapa2d.js?v=<?= filemtime(__DIR__ . '/../../js/mapa2d.js') ?>" defer></script>
<script src="js/mapa.js?v=<?= filemtime(__DIR__ . '/../../js/mapa.js') ?>" defer></script>
