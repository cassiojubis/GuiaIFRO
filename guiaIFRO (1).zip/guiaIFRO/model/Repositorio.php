<?php
/**
 * CAMADA DE ACESSO A DADOS (Model)
 *
 * Único lugar do site que fala com o banco. Controllers e views só chamam
 * estas funções (nunca escrevem SQL). Tudo com prepared statements
 * (ver consultar()/executar() em model/Banco.php).
 */

require_once __DIR__ . '/Banco.php';
require_once __DIR__ . '/Horario.php';

/* =============================================================
 * SETORES E CATEGORIAS
 * ============================================================= */

/** Categorias de verdade (grupos do organograma), na ordem do admin. */
function listarGruposCategorias(bool $incluirInativas = false): array
{
    return consultar(
        'SELECT c.id, c.nome, c.icone, c.cor, c.ordem, c.ativo, c.atualizado_em,
                (SELECT COUNT(*) FROM setores s WHERE s.categoria_id = c.id AND s.ativo = 1) AS total_setores
           FROM categorias c
          WHERE c.ativo = 1 OR :todas = 1
          ORDER BY c.ordem, c.nome',
        ['todas' => $incluirInativas ? 1 : 0]
    );
}

function buscarGrupoCategoria(string $id): ?array
{
    return consultarUm('SELECT * FROM categorias WHERE id = ?', [$id]);
}

/**
 * Cards da página Categorias e da home: um card por SETOR, com o grupo em 'tag'.
 * (O nome "listarCategorias" ficou de quando cada item do organograma era
 * chamado de categoria.) Todo setor ativo tem página, então todos têm url_setor.
 */
function listarCategorias(): array
{
    $linhas = consultar(
        'SELECT s.id, s.icone, s.nome, s.sigla, s.cor, s.descricao, s.descricao_curta,
                c.nome AS grupo
           FROM setores s
           LEFT JOIN categorias c ON c.id = s.categoria_id
          WHERE s.ativo = 1 AND (c.id IS NULL OR c.ativo = 1)
          ORDER BY c.ordem, s.ordem, s.nome'
    );

    return array_map(static function (array $setor) {
        $titulo = $setor['sigla'] !== '' && stripos($setor['nome'], $setor['sigla']) === false
            ? $setor['sigla'] . ' – ' . $setor['nome']
            : $setor['nome'];
        $descricao = $setor['descricao_curta'] ?: ($setor['descricao'] ?: 'Informações em breve.');
        return [
            'id' => $setor['id'],
            'setor_id' => $setor['id'],
            'icone' => $setor['icone'],
            'titulo' => $titulo,
            'descricaoCurta' => $descricao,
            'descricao' => $descricao,
            'tag' => $setor['grupo'] ?? 'Outros',
            'cor' => $setor['cor'],
            'setores' => [$setor['nome'], $setor['sigla']],
            'url_setor' => 'setor.php?id=' . rawurlencode($setor['id']),
        ];
    }, $linhas);
}

/** Card de um setor (mesmo formato de listarCategorias), ou null. */
function buscarCategoriaPorId(string $id): ?array
{
    foreach (listarCategorias() as $categoria) {
        if ($categoria['id'] === $id) {
            return $categoria;
        }
    }
    return null;
}

/** Setores ativos, com os campos básicos (busca ao vivo, sitemap, listas). */
function listarSetores(bool $incluirInativos = false): array
{
    return consultar(
        'SELECT s.id, s.nome, s.sigla, s.icone, s.cor, s.categoria_id, c.nome AS categoria_nome,
                s.descricao, s.descricao_curta, s.localizacao, s.bloco, s.sala_texto AS sala,
                s.telefone, s.email, s.responsavel, s.horario_texto AS horario,
                s.ativo, s.ordem, s.atualizado_em, s.atualizado_por
           FROM setores s
           LEFT JOIN categorias c ON c.id = s.categoria_id
          WHERE s.ativo = 1 OR :todos = 1
          ORDER BY c.ordem, s.ordem, s.nome',
        ['todos' => $incluirInativos ? 1 : 0]
    );
}

/**
 * Setor completo pra página do setor (com equipe, serviços e documentos), ou null.
 * Setor desativado no admin some do site (devolve null = página 404).
 */
function buscarSetorPorId(string $id, bool $incluirInativo = false): ?array
{
    $setor = consultarUm(
        'SELECT s.*, s.sala_texto AS sala, s.horario_texto AS horario, s.categoria_id AS categoria,
                c.nome AS categoria_nome
           FROM setores s
           LEFT JOIN categorias c ON c.id = s.categoria_id
          WHERE s.id = ?',
        [$id]
    );
    if ($setor === null || (!$incluirInativo && !(int) $setor['ativo'])) {
        return null;
    }

    $setor['equipe'] = array_column(consultar('SELECT nome FROM setor_equipe WHERE setor_id = ? ORDER BY ordem, id', [$id]), 'nome');
    $setor['servicos'] = array_column(consultar('SELECT nome FROM setor_servicos WHERE setor_id = ? ORDER BY ordem, id', [$id]), 'nome');
    $setor['documentos'] = array_column(consultar('SELECT nome FROM setor_documentos WHERE setor_id = ? ORDER BY ordem, id', [$id]), 'nome');
    $setor['sinonimos'] = array_column(consultar('SELECT nome FROM sinonimos WHERE setor_id = ? ORDER BY ordem, id', [$id]), 'nome');
    return $setor;
}

/* =============================================================
 * HOME E CONTEÚDO
 * ============================================================= */

function listarAtalhosRapidos(): array
{
    return consultar('SELECT titulo, descricao, icone, cor, url FROM atalhos_home ORDER BY ordem, id');
}

/** "2026-05-24" -> "24 mai 2026" */
function formatarDataCurta(string $data): string
{
    $meses = ['jan', 'fev', 'mar', 'abr', 'mai', 'jun', 'jul', 'ago', 'set', 'out', 'nov', 'dez'];
    $momento = new DateTimeImmutable($data);
    return $momento->format('j') . ' ' . $meses[(int) $momento->format('n') - 1] . ' ' . $momento->format('Y');
}

/** Notícias publicadas, mais novas primeiro. */
function listarNoticias(int $limite = 6): array
{
    $linhas = consultar(
        'SELECT id, slug, titulo, resumo, categoria, publicada_em, destaque
           FROM noticias
          WHERE publicado = 1
          ORDER BY publicada_em DESC, ordem, id DESC
          LIMIT ' . max(1, $limite)
    );
    return array_map(static function (array $noticia) {
        $noticia['data'] = formatarDataCurta($noticia['publicada_em']);
        $noticia['urgente'] = (bool) $noticia['destaque'];
        return $noticia;
    }, $linhas);
}

/* =============================================================
 * MAPA
 * ============================================================= */

/**
 * Andares e salas do mapa do campus (mapa.php), no mesmo formato que o js/mapa.js
 * sempre usou. Cada sala ganha 'url_setor' quando tem setor com página.
 */
function listarMapaSalas(): array
{
    $andares = [];
    foreach (consultar('SELECT id, nome FROM andares ORDER BY ordem') as $andar) {
        $andares[$andar['id']] = ['nome' => $andar['nome']];
    }

    $salas = array_map(static function (array $sala) {
        $temSetor = $sala['setor_id'] !== null && (int) $sala['setor_ativo'] === 1;
        return [
            'id' => $sala['id'],
            'nome' => $sala['nome'],
            'nomeCurto' => $sala['nome_curto'],
            'funcao' => $sala['funcao'],
            'andar' => $sala['andar_id'],
            'ala' => $sala['ala'],
            'ordem' => (int) $sala['ordem'],
            'lado' => $sala['lado'],
            'ponta' => (bool) $sala['ponta'],
            'vazia' => (bool) $sala['vazia'],
            'setor_id' => $temSetor ? $sala['setor_id'] : null,
            'setor_id_cadastrado' => $sala['setor_id'], // mesmo se o setor estiver desativado (pro editor)
            'url_setor' => $temSetor ? 'setor.php?id=' . rawurlencode($sala['setor_id']) : null,
            // Sala sem setor (banheiro, copa, auditório...) ganha uma ficha simples.
            'url_ficha' => 'sala.php?id=' . rawurlencode($sala['id']),
        ];
    }, consultar(
        'SELECT sa.*, se.ativo AS setor_ativo
           FROM salas sa
           LEFT JOIN setores se ON se.id = sa.setor_id
          ORDER BY sa.andar_id, sa.ala, sa.ordem'
    ));

    return ['andares' => $andares, 'salas' => $salas];
}

function buscarSalaDoMapa(string $id): ?array
{
    foreach (listarMapaSalas()['salas'] as $sala) {
        if ($sala['id'] === $id) {
            return $sala;
        }
    }
    return null;
}

/** Salas do mapa ligadas a um setor (normalmente uma só). */
function listarSalasDoSetor(string $idSetor): array
{
    return array_values(array_filter(listarMapaSalas()['salas'], static function ($sala) use ($idSetor) {
        return $sala['setor_id'] === $idSetor;
    }));
}

/* =============================================================
 * FAQ
 * ============================================================= */

/** Perguntas frequentes de um setor (só as publicadas). Sem setor = FAQ geral. */
function listarFaqSetor(?string $idSetor = null): array
{
    if ($idSetor === null) {
        return consultar(
            'SELECT f.id, f.pergunta, f.resposta FROM faq f
              WHERE f.publicado = 1 AND NOT EXISTS (SELECT 1 FROM faq_setor fs WHERE fs.faq_id = f.id)
              ORDER BY f.ordem, f.id'
        );
    }
    return consultar(
        'SELECT f.id, f.pergunta, f.resposta FROM faq f
           JOIN faq_setor fs ON fs.faq_id = f.id
          WHERE fs.setor_id = ? AND f.publicado = 1
          ORDER BY f.ordem, f.id',
        [$idSetor]
    );
}

/* =============================================================
 * CONFIGURAÇÕES (contato geral, redes sociais...)
 * ============================================================= */

/** Todas as configurações como [chave => valor]. Lidas uma vez por requisição. */
function listarConfiguracoes(): array
{
    static $cache = null;
    if ($cache === null) {
        $cache = [];
        foreach (consultar('SELECT chave, valor FROM configuracoes') as $linha) {
            $cache[$linha['chave']] = (string) $linha['valor'];
        }
    }
    return $cache;
}

function configuracao(string $chave, string $padrao = ''): string
{
    $valor = listarConfiguracoes()[$chave] ?? '';
    return $valor !== '' ? $valor : $padrao;
}

/* =============================================================
 * LIMITE DE ENVIOS (contato e login)
 * Guarda só o hash da chave (IP com sal), nunca o IP.
 * ============================================================= */

/** Já passou do limite? Ex.: limiteAtingido('contato', $hash, 3, 3600) = 3 por hora. */
function limiteAtingido(string $acao, string $chaveHash, int $maximo, int $janelaSegundos): bool
{
    $quantidade = (int) consultarValor(
        'SELECT COUNT(*) FROM limites WHERE acao = ? AND chave_hash = ? AND criado_em > (NOW() - INTERVAL ? SECOND)',
        [$acao, $chaveHash, $janelaSegundos]
    );
    return $quantidade >= $maximo;
}

function registrarNoLimite(string $acao, string $chaveHash): void
{
    executar('INSERT INTO limites (acao, chave_hash) VALUES (?, ?)', [$acao, $chaveHash]);
    // De vez em quando limpa o que tem mais de 1 dia (não precisa guardar).
    if (random_int(1, 50) === 1) {
        executar('DELETE FROM limites WHERE criado_em < (NOW() - INTERVAL 1 DAY)');
    }
}

function limparLimite(string $acao, string $chaveHash): void
{
    executar('DELETE FROM limites WHERE acao = ? AND chave_hash = ?', [$acao, $chaveHash]);
}

/* =============================================================
 * MENSAGENS DO FORMULÁRIO DE CONTATO
 * ============================================================= */

/** Assuntos aceitos no formulário (o servidor recusa qualquer outro). */
function listarAssuntosContato(): array
{
    return [
        'Dúvida sobre matrícula',
        'Assistência estudantil',
        'Biblioteca',
        'Estágio e SUAP',
        'Solicitação de documentos',
        'Sugestão ou elogio',
        'Outro assunto',
    ];
}

/** Grava a mensagem e devolve o id. */
function salvarMensagemContato(array $dados): int
{
    executar(
        'INSERT INTO contatos_mensagens (nome, email, telefone, assunto, mensagem) VALUES (?, ?, ?, ?, ?)',
        [$dados['nome'], $dados['email'], $dados['telefone'] !== '' ? $dados['telefone'] : null, $dados['assunto'], $dados['mensagem']]
    );
    return (int) banco()->lastInsertId();
}

function marcarEmailEnviado(int $idMensagem): void
{
    executar('UPDATE contatos_mensagens SET email_enviado = 1 WHERE id = ?', [$idMensagem]);
}

function listarMensagensContato(int $limite = 100): array
{
    return consultar('SELECT * FROM contatos_mensagens ORDER BY criada_em DESC, id DESC LIMIT ' . max(1, $limite));
}

function contarMensagensNaoLidas(): int
{
    return (int) consultarValor('SELECT COUNT(*) FROM contatos_mensagens WHERE lida_em IS NULL');
}

function marcarMensagemLida(int $id, bool $lida): void
{
    executar('UPDATE contatos_mensagens SET lida_em = ' . ($lida ? 'NOW()' : 'NULL') . ' WHERE id = ?', [$id]);
}

function excluirMensagemContato(int $id): void
{
    executar('DELETE FROM contatos_mensagens WHERE id = ?', [$id]);
}

/* =============================================================
 * USUÁRIOS E PERMISSÕES (B3)
 * ============================================================= */

/** Busca pelo nome de usuário OU pelo e-mail (o login aceita os dois). */
function buscarUsuarioPorLogin(string $login): ?array
{
    return consultarUm('SELECT * FROM usuarios WHERE usuario = ? OR (email IS NOT NULL AND email = ?) LIMIT 1', [$login, $login]);
}

function buscarUsuarioPorId(int $id): ?array
{
    return consultarUm('SELECT * FROM usuarios WHERE id = ?', [$id]);
}

function listarUsuarios(): array
{
    $usuarios = consultar(
        'SELECT u.id, u.nome, u.usuario, u.email, u.perfil_id, p.nome AS perfil_nome, u.ativo, u.ultimo_login_em, u.criado_em
           FROM usuarios u JOIN perfis p ON p.id = u.perfil_id
          ORDER BY u.ativo DESC, u.nome'
    );
    foreach ($usuarios as &$usuario) {
        $usuario['setores'] = listarIdsSetoresDoUsuario((int) $usuario['id']);
    }
    return $usuarios;
}

function listarPerfis(): array
{
    return consultar('SELECT id, nome FROM perfis ORDER BY nome');
}

function listarIdsSetoresDoUsuario(int $idUsuario): array
{
    return array_column(consultar('SELECT setor_id FROM usuario_setor WHERE usuario_id = ? ORDER BY setor_id', [$idUsuario]), 'setor_id');
}

/** Responsáveis de um setor (pra mostrar "atualizado por" e mandar aviso de revisão). */
function listarResponsaveisDoSetor(string $idSetor): array
{
    return consultar(
        'SELECT u.id, u.nome, u.email FROM usuarios u JOIN usuario_setor us ON us.usuario_id = u.id
          WHERE us.setor_id = ? AND u.ativo = 1 ORDER BY u.nome',
        [$idSetor]
    );
}

function usuarioOuEmailEmUso(string $usuario, ?string $email, int $ignorarId = 0): bool
{
    $email = $email ?: null;
    return (int) consultarValor(
        'SELECT COUNT(*) FROM usuarios WHERE id <> ? AND (usuario = ? OR (email IS NOT NULL AND email = ?))',
        [$ignorarId, $usuario, $email]
    ) > 0;
}

function criarUsuario(array $dados, string $senhaHash): int
{
    executar(
        'INSERT INTO usuarios (nome, usuario, email, senha_hash, perfil_id, ativo) VALUES (?, ?, ?, ?, ?, ?)',
        [$dados['nome'], $dados['usuario'], $dados['email'] ?: null, $senhaHash, $dados['perfil_id'], $dados['ativo'] ? 1 : 0]
    );
    return (int) banco()->lastInsertId();
}

/** Atualiza o cadastro. Desativar o usuário também derruba as sessões dele. */
function atualizarUsuario(int $id, array $dados): void
{
    executar(
        'UPDATE usuarios SET nome = ?, usuario = ?, email = ?, perfil_id = ?, ativo = ?,
                sessao_versao = sessao_versao + IF(? = 0, 1, 0)
          WHERE id = ?',
        [$dados['nome'], $dados['usuario'], $dados['email'] ?: null, $dados['perfil_id'], $dados['ativo'] ? 1 : 0, $dados['ativo'] ? 1 : 0, $id]
    );
}

/** Troca a senha. Com $derrubarSessoes, desloga o usuário de todos os aparelhos. */
function definirSenhaUsuario(int $id, string $senhaHash, bool $derrubarSessoes = true): void
{
    executar(
        'UPDATE usuarios SET senha_hash = ?' . ($derrubarSessoes ? ', sessao_versao = sessao_versao + 1' : '') . ' WHERE id = ?',
        [$senhaHash, $id]
    );
}

function atualizarMeusDados(int $id, string $nome, ?string $email): void
{
    executar('UPDATE usuarios SET nome = ?, email = ? WHERE id = ?', [$nome, $email ?: null, $id]);
}

/** "Sair de todos os aparelhos": muda a versão e toda sessão antiga deixa de valer. Devolve a versão nova. */
function encerrarTodasAsSessoes(int $id): int
{
    executar('UPDATE usuarios SET sessao_versao = sessao_versao + 1 WHERE id = ?', [$id]);
    return (int) consultarValor('SELECT sessao_versao FROM usuarios WHERE id = ?', [$id]);
}

function registrarLoginUsuario(int $id): void
{
    executar('UPDATE usuarios SET ultimo_login_em = NOW() WHERE id = ?', [$id]);
}

function definirSetoresDoUsuario(int $idUsuario, array $idsSetores): void
{
    executar('DELETE FROM usuario_setor WHERE usuario_id = ?', [$idUsuario]);
    foreach (array_unique($idsSetores) as $idSetor) {
        executar('INSERT INTO usuario_setor (usuario_id, setor_id) SELECT ?, id FROM setores WHERE id = ?', [$idUsuario, $idSetor]);
    }
}

function contarAdminsGeraisAtivos(int $ignorarId = 0): int
{
    return (int) consultarValor("SELECT COUNT(*) FROM usuarios WHERE perfil_id = 'admin_geral' AND ativo = 1 AND id <> ?", [$ignorarId]);
}

/* =============================================================
 * AUDITORIA: toda alteração feita no admin fica registrada
 * ============================================================= */

/**
 * $usuario = usuarioAtual() (quem fez). $antes/$depois viram JSON.
 * $resumo é a frase que aparece no dashboard (ex.: 'Setor "CRA" editado').
 */
function registrarAuditoria(?array $usuario, string $acao, string $tabela, ?string $registroId, ?array $antes, ?array $depois, string $resumo): void
{
    $json = static function (?array $dados): ?string {
        return $dados === null ? null : json_encode($dados, JSON_UNESCAPED_UNICODE);
    };
    executar(
        'INSERT INTO auditoria (usuario_id, usuario_nome, acao, tabela, registro_id, resumo, antes, depois) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
        [$usuario['id'] ?? null, $usuario['nome'] ?? 'Sistema', $acao, $tabela, $registroId, mb_substr($resumo, 0, 255), $json($antes), $json($depois)]
    );
}

function listarAuditoria(int $limite = 10, ?string $tabela = null, ?string $registroId = null): array
{
    $filtros = [];
    $parametros = [];
    if ($tabela !== null) {
        $filtros[] = 'tabela = ?';
        $parametros[] = $tabela;
    }
    if ($registroId !== null) {
        $filtros[] = 'registro_id = ?';
        $parametros[] = $registroId;
    }
    return consultar(
        'SELECT id, usuario_nome, acao, tabela, registro_id, resumo, quando FROM auditoria'
        . ($filtros ? ' WHERE ' . implode(' AND ', $filtros) : '')
        . ' ORDER BY quando DESC, id DESC LIMIT ' . max(1, $limite),
        $parametros
    );
}

/* =============================================================
 * ADMIN: ORDEM DAS LISTAS
 * ============================================================= */

/**
 * Sobe/desce um item na lista (troca a ordem com o vizinho).
 * $tabela e $colunaId vêm sempre do próprio código (nunca do usuário).
 */
function moverNaOrdem(string $tabela, string $colunaId, $id, string $direcao): void
{
    $atual = consultarUm("SELECT {$colunaId} AS id, ordem FROM {$tabela} WHERE {$colunaId} = ?", [$id]);
    if (!$atual) {
        return;
    }
    $todos = consultar("SELECT {$colunaId} AS id FROM {$tabela} ORDER BY ordem, {$colunaId}");
    $ids = array_column($todos, 'id');
    $posicao = array_search($atual['id'], $ids, false);
    $alvo = $direcao === 'cima' ? $posicao - 1 : $posicao + 1;
    if ($posicao === false || $alvo < 0 || $alvo >= count($ids)) {
        return;
    }
    // Troca os dois de lugar e regrava a ordem de todo mundo (0, 1, 2...): simples e sem empate.
    [$ids[$posicao], $ids[$alvo]] = [$ids[$alvo], $ids[$posicao]];
    foreach ($ids as $novaOrdem => $idItem) {
        executar("UPDATE {$tabela} SET ordem = ? WHERE {$colunaId} = ?", [$novaOrdem, $idItem]);
    }
}

/** Gera um id (slug) livre: "Biblioteca" -> "biblioteca", "biblioteca-2"... ($tabela vem do código) */
function gerarIdLivre(string $tabela, string $texto, string $coluna = 'id'): string
{
    $base = criarSlugTexto($texto, 50);
    $id = $base;
    $numero = 2;
    while ((int) consultarValor("SELECT COUNT(*) FROM {$tabela} WHERE {$coluna} = ?", [$id]) > 0) {
        $id = $base . '-' . $numero++;
    }
    return $id;
}

/* =============================================================
 * ADMIN: CATEGORIAS
 * ============================================================= */

function criarCategoria(array $dados): string
{
    $id = gerarIdLivre('categorias', $dados['nome']);
    $ordem = (int) consultarValor('SELECT COALESCE(MAX(ordem), 0) + 1 FROM categorias');
    executar(
        'INSERT INTO categorias (id, nome, icone, cor, ordem, ativo) VALUES (?, ?, ?, ?, ?, ?)',
        [$id, $dados['nome'], $dados['icone'], $dados['cor'], $ordem, $dados['ativo'] ? 1 : 0]
    );
    return $id;
}

function atualizarCategoria(string $id, array $dados): void
{
    executar(
        'UPDATE categorias SET nome = ?, icone = ?, cor = ?, ativo = ? WHERE id = ?',
        [$dados['nome'], $dados['icone'], $dados['cor'], $dados['ativo'] ? 1 : 0, $id]
    );
}

function alternarCategoriaAtiva(string $id): void
{
    executar('UPDATE categorias SET ativo = 1 - ativo WHERE id = ?', [$id]);
}

/** Exclui a categoria. Os setores dela ficam "sem categoria" (não são apagados). */
function excluirCategoria(string $id): void
{
    executar('DELETE FROM categorias WHERE id = ?', [$id]);
}

/* =============================================================
 * ADMIN: SETORES
 * ============================================================= */

function setorExiste(string $id): bool
{
    return (int) consultarValor('SELECT COUNT(*) FROM setores WHERE id = ?', [$id]) > 0;
}

/**
 * Cria ($idExistente null) ou atualiza um setor, com as listas (equipe, serviços,
 * documentos) quando vierem em $dados. Tudo numa transação: grava tudo ou nada.
 * Devolve o id do setor.
 */
function salvarSetor(?string $idExistente, array $dados, string $autor): string
{
    $colunasPermitidas = [
        'categoria_id', 'nome', 'sigla', 'icone', 'cor', 'descricao', 'descricao_curta', 'texto_facil',
        'localizacao', 'bloco', 'sala_texto', 'telefone', 'email', 'responsavel', 'horario_texto', 'ativo',
    ];
    $campos = [];
    foreach ($colunasPermitidas as $coluna) {
        if (array_key_exists($coluna, $dados)) {
            $valor = $dados[$coluna];
            $campos[$coluna] = is_bool($valor) ? (int) $valor : ($valor === '' && $coluna !== 'sigla' ? null : $valor);
        }
    }
    $campos['atualizado_por'] = $autor;

    $pdo = banco();
    $pdo->beginTransaction();
    try {
        if ($idExistente === null) {
            $id = gerarIdLivre('setores', ($dados['sigla'] ?? '') !== '' ? $dados['sigla'] : $dados['nome']);
            $campos['id'] = $id;
            $campos['ordem'] = (int) consultarValor('SELECT COALESCE(MAX(ordem), 0) + 1 FROM setores');
            $colunas = array_keys($campos);
            executar(
                'INSERT INTO setores (' . implode(', ', $colunas) . ', atualizado_em) VALUES (' . implode(', ', array_fill(0, count($colunas), '?')) . ', NOW())',
                array_values($campos)
            );
        } else {
            $id = $idExistente;
            $sets = implode(', ', array_map(static function ($coluna) { return "{$coluna} = ?"; }, array_keys($campos)));
            executar("UPDATE setores SET {$sets}, atualizado_em = NOW() WHERE id = ?", array_merge(array_values($campos), [$id]));
        }

        foreach (['setor_equipe' => 'equipe', 'setor_servicos' => 'servicos', 'setor_documentos' => 'documentos', 'sinonimos' => 'sinonimos'] as $tabela => $chave) {
            if (!array_key_exists($chave, $dados)) {
                continue;
            }
            executar("DELETE FROM {$tabela} WHERE setor_id = ?", [$id]);
            foreach (array_values($dados[$chave]) as $posicao => $nome) {
                executar("INSERT INTO {$tabela} (setor_id, nome, ordem) VALUES (?, ?, ?)", [$id, $nome, $posicao]);
            }
        }

        $pdo->commit();
        return $id;
    } catch (Throwable $erro) {
        $pdo->rollBack();
        throw $erro;
    }
}

function alternarSetorAtivo(string $id): void
{
    executar('UPDATE setores SET ativo = 1 - ativo, atualizado_em = NOW() WHERE id = ?', [$id]);
}

/** Exclui o setor (equipe, serviços, horários... vão junto; salas do mapa ficam sem setor). */
function excluirSetor(string $id): void
{
    executar('DELETE FROM setores WHERE id = ?', [$id]);
}

/** Setores ativos que ainda não têm nenhuma informação de contato/horário/local (pra preencher). */
function listarSetoresSemDados(): array
{
    return consultar(
        "SELECT s.id, s.nome, s.sigla, c.nome AS categoria_nome
           FROM setores s LEFT JOIN categorias c ON c.id = s.categoria_id
          WHERE s.ativo = 1
            AND COALESCE(s.telefone, '') = '' AND COALESCE(s.email, '') = ''
            AND COALESCE(s.horario_texto, '') = '' AND COALESCE(s.localizacao, '') = ''
            AND NOT EXISTS (SELECT 1 FROM setor_horarios h WHERE h.setor_id = s.id)
          ORDER BY c.ordem, s.ordem"
    );
}

/* =============================================================
 * ADMIN: INFORMAÇÕES (avisos, notícias, calendário, FAQ, links, institucional)
 * Cada aba é uma tabela. Nomes de tabela/coluna vêm desta lista fixa,
 * nunca do que o usuário mandou.
 * ============================================================= */

function abasInformacao(): array
{
    return [
        'avisos' => ['tabela' => 'avisos', 'campos' => ['titulo', 'mensagem', 'nivel', 'inicio', 'fim'], 'titulo' => 'titulo'],
        'noticias' => ['tabela' => 'noticias', 'campos' => ['titulo', 'resumo', 'conteudo', 'categoria', 'publicada_em', 'destaque'], 'titulo' => 'titulo'],
        'calendario' => ['tabela' => 'eventos', 'campos' => ['titulo', 'descricao', 'inicio', 'fim', 'tipo', 'periodo_letivo'], 'titulo' => 'titulo'],
        'faq' => ['tabela' => 'faq', 'campos' => ['pergunta', 'resposta'], 'titulo' => 'pergunta'],
        'links' => ['tabela' => 'links_uteis', 'campos' => ['titulo', 'url'], 'titulo' => 'titulo'],
        'institucional' => ['tabela' => 'textos_institucionais', 'campos' => ['titulo', 'conteudo'], 'titulo' => 'titulo'],
    ];
}

function listarItensInformacao(string $aba): array
{
    $config = abasInformacao()[$aba] ?? null;
    if (!$config) {
        return [];
    }
    $itens = consultar("SELECT * FROM {$config['tabela']} ORDER BY ordem, id DESC");
    if ($aba === 'faq') {
        foreach ($itens as &$item) {
            $item['setores'] = array_column(consultar('SELECT setor_id FROM faq_setor WHERE faq_id = ?', [$item['id']]), 'setor_id');
        }
    }
    return $itens;
}

function buscarItemInformacao(string $aba, int $id): ?array
{
    $config = abasInformacao()[$aba] ?? null;
    return $config ? consultarUm("SELECT * FROM {$config['tabela']} WHERE id = ?", [$id]) : null;
}

/** Cria (id null) ou atualiza um item. Devolve o id. */
function salvarItemInformacao(string $aba, ?int $id, array $valores): int
{
    $config = abasInformacao()[$aba];
    $campos = [];
    foreach ($config['campos'] as $campo) {
        $campos[$campo] = $valores[$campo] ?? null;
    }

    if ($id === null) {
        $campos['ordem'] = (int) consultarValor("SELECT COALESCE(MIN(ordem), 0) - 1 FROM {$config['tabela']}");
        if ($aba === 'noticias') {
            $campos['slug'] = gerarIdLivre('noticias', $valores['titulo'], 'slug');
        }
        $colunas = array_keys($campos);
        executar(
            "INSERT INTO {$config['tabela']} (" . implode(', ', $colunas) . ') VALUES (' . implode(', ', array_fill(0, count($colunas), '?')) . ')',
            array_values($campos)
        );
        $id = (int) banco()->lastInsertId();
    } else {
        $sets = implode(', ', array_map(static function ($coluna) { return "{$coluna} = ?"; }, array_keys($campos)));
        executar("UPDATE {$config['tabela']} SET {$sets} WHERE id = ?", array_merge(array_values($campos), [$id]));
    }

    if ($aba === 'faq' && array_key_exists('setores', $valores)) {
        executar('DELETE FROM faq_setor WHERE faq_id = ?', [$id]);
        foreach (array_unique($valores['setores']) as $idSetor) {
            executar('INSERT INTO faq_setor (faq_id, setor_id) SELECT ?, id FROM setores WHERE id = ?', [$id, $idSetor]);
        }
    }
    return $id;
}

function alternarPublicacaoInformacao(string $aba, int $id): void
{
    $config = abasInformacao()[$aba];
    executar("UPDATE {$config['tabela']} SET publicado = 1 - publicado WHERE id = ?", [$id]);
}

function excluirItemInformacao(string $aba, int $id): void
{
    $config = abasInformacao()[$aba];
    executar("DELETE FROM {$config['tabela']} WHERE id = ?", [$id]);
}

function moverItemInformacao(string $aba, int $id, string $direcao): void
{
    moverNaOrdem(abasInformacao()[$aba]['tabela'], 'id', $id, $direcao);
}

/* =============================================================
 * ADMIN: CONFIGURAÇÕES E DASHBOARD
 * ============================================================= */

function salvarConfiguracoes(array $valores): void
{
    foreach ($valores as $chave => $valor) {
        executar(
            'INSERT INTO configuracoes (chave, valor) VALUES (?, ?) ON DUPLICATE KEY UPDATE valor = VALUES(valor)',
            [$chave, $valor]
        );
    }
}

/** Números reais do dashboard. */
function contagensDashboard(): array
{
    return [
        'categorias' => (int) consultarValor('SELECT COUNT(*) FROM categorias WHERE ativo = 1'),
        'setores' => (int) consultarValor('SELECT COUNT(*) FROM setores WHERE ativo = 1'),
        'informacoes' => (int) consultarValor(
            'SELECT (SELECT COUNT(*) FROM avisos WHERE publicado = 1) + (SELECT COUNT(*) FROM noticias WHERE publicado = 1)
                  + (SELECT COUNT(*) FROM eventos WHERE publicado = 1) + (SELECT COUNT(*) FROM faq WHERE publicado = 1)'
        ),
        'mensagens_nao_lidas' => contarMensagensNaoLidas(),
        'setores_sem_dados' => count(listarSetoresSemDados()),
    ];
}

/* =============================================================
 * HORÁRIOS ESTRUTURADOS (B4)
 * ============================================================= */

function listarHorariosSetor(string $idSetor): array
{
    return consultar(
        'SELECT id, dia_semana, TIME_FORMAT(abre, "%H:%i:00") AS abre, TIME_FORMAT(fecha, "%H:%i:00") AS fecha, observacao
           FROM setor_horarios WHERE setor_id = ? ORDER BY FIELD(dia_semana, 1, 2, 3, 4, 5, 6, 0), abre',
        [$idSetor]
    );
}

/** Troca todas as faixas do setor pelas novas (numa transação). */
function salvarHorariosSetor(string $idSetor, array $faixas): void
{
    $pdo = banco();
    $pdo->beginTransaction();
    try {
        executar('DELETE FROM setor_horarios WHERE setor_id = ?', [$idSetor]);
        foreach ($faixas as $faixa) {
            executar(
                'INSERT INTO setor_horarios (setor_id, dia_semana, abre, fecha) VALUES (?, ?, ?, ?)',
                [$idSetor, (int) $faixa['dia_semana'], $faixa['abre'], $faixa['fecha']]
            );
        }
        executar('UPDATE setores SET atualizado_em = NOW() WHERE id = ?', [$idSetor]);
        $pdo->commit();
    } catch (Throwable $erro) {
        $pdo->rollBack();
        throw $erro;
    }
}

/** Exceções futuras (e de hoje) do setor. $incluirCampus traz também as do campus todo. */
function listarExcecoes(?string $idSetor, bool $incluirCampus = false): array
{
    if ($idSetor === null) {
        return consultar('SELECT * FROM setor_excecoes WHERE setor_id IS NULL AND data >= CURDATE() ORDER BY data');
    }
    return consultar(
        'SELECT * FROM setor_excecoes WHERE (setor_id = ?' . ($incluirCampus ? ' OR setor_id IS NULL' : '') . ') AND data >= CURDATE() ORDER BY data',
        [$idSetor]
    );
}

function buscarExcecao(int $id): ?array
{
    return consultarUm('SELECT * FROM setor_excecoes WHERE id = ?', [$id]);
}

function criarExcecao(?string $idSetor, string $data, bool $fechado, ?string $abre, ?string $fecha, string $motivo): int
{
    executar(
        'INSERT INTO setor_excecoes (setor_id, data, fechado, abre, fecha, motivo) VALUES (?, ?, ?, ?, ?, ?)',
        [$idSetor, $data, $fechado ? 1 : 0, $fechado ? null : $abre, $fechado ? null : $fecha, $motivo]
    );
    return (int) banco()->lastInsertId();
}

function excluirExcecao(int $id): void
{
    executar('DELETE FROM setor_excecoes WHERE id = ?', [$id]);
}

/**
 * Exceções dos próximos dias (hoje + 7), por data, pra um setor:
 * as do setor, as do campus todo e os feriados/recessos publicados no calendário.
 */
function excecoesProximosDias(string $idSetor, DateTimeImmutable $agora): array
{
    $inicio = $agora->format('Y-m-d');
    $fim = $agora->modify('+8 day')->format('Y-m-d');
    $porData = [];
    foreach (consultar(
        'SELECT data, fechado, abre, fecha, motivo FROM setor_excecoes
          WHERE (setor_id = ? OR setor_id IS NULL) AND data BETWEEN ? AND ?',
        [$idSetor, $inicio, $fim]
    ) as $excecao) {
        $porData[$excecao['data']][] = $excecao;
    }
    // Feriado/recesso do calendário acadêmico fecha o campus inteiro.
    foreach (consultar(
        "SELECT titulo, inicio, COALESCE(fim, inicio) AS fim FROM eventos
          WHERE publicado = 1 AND tipo IN ('feriado', 'recesso') AND inicio <= ? AND COALESCE(fim, inicio) >= ?",
        [$fim, $inicio]
    ) as $evento) {
        $dia = new DateTimeImmutable(max($evento['inicio'], $inicio));
        $ultimo = new DateTimeImmutable(min($evento['fim'], $fim));
        while ($dia <= $ultimo) {
            $porData[$dia->format('Y-m-d')][] = ['data' => $dia->format('Y-m-d'), 'fechado' => 1, 'abre' => null, 'fecha' => null, 'motivo' => $evento['titulo']];
            $dia = $dia->modify('+1 day');
        }
    }
    return $porData;
}

/**
 * Selo "Aberto agora" de um setor: usa o horário estruturado; se o setor ainda
 * não tem horário estruturado, cai no texto antigo (setorEstaAberto).
 * Devolve ['aberto' => bool|null, 'resumo' => string|null, 'faixas' => [...]].
 */
function estadoHorarioSetor(array $setor, ?DateTimeImmutable $agora = null): array
{
    $agora = $agora ?? new DateTimeImmutable('now');
    $faixas = listarHorariosSetor($setor['id']);
    if ($faixas) {
        return estadoHorario($faixas, excecoesProximosDias($setor['id'], $agora), $agora) + ['faixas' => $faixas];
    }
    return ['aberto' => setorEstaAberto((string) ($setor['horario'] ?? ''), $agora), 'resumo' => null, 'faixas' => []];
}

/* =============================================================
 * EDITOR DO MAPA (B6): salas e peças do cenário
 * ============================================================= */

/** Tipos de peça do cenário e o rótulo que aparece no editor. */
function tiposPecaMapa(): array
{
    return [
        'bloco' => 'Bloco / prédio', 'obra' => 'Obra', 'quadra' => 'Quadra',
        'estacionamento' => 'Estacionamento', 'area_verde' => 'Área verde', 'arvore' => 'Árvore',
        'estande' => 'Estande (evento)',
    ];
}

/**
 * Peças do cenário. Com $soDeAgora, só as que valem agora (peça com início/fim
 * é temporária: estande de feira, obra, evento — W3).
 */
function listarPecasMapa(bool $soDeAgora = true): array
{
    $pecas = consultar(
        'SELECT id, tipo, nome, x, z, largura, profundidade, rotacao, inicio, fim FROM pecas_mapa'
        . ($soDeAgora ? ' WHERE (inicio IS NULL OR inicio <= NOW()) AND (fim IS NULL OR fim >= NOW())' : '')
        . ' ORDER BY id'
    );
    return array_map(static function (array $peca) {
        foreach (['x', 'z', 'largura', 'profundidade', 'rotacao'] as $numero) {
            $peca[$numero] = (float) $peca[$numero];
        }
        $peca['id'] = (int) $peca['id'];
        return $peca;
    }, $pecas);
}

/** Troca todas as peças pelas novas (o editor manda a lista inteira). */
function salvarPecasMapa(array $pecas): void
{
    $pdo = banco();
    $pdo->beginTransaction();
    try {
        executar('DELETE FROM pecas_mapa');
        foreach ($pecas as $peca) {
            executar(
                'INSERT INTO pecas_mapa (tipo, nome, x, z, largura, profundidade, rotacao, inicio, fim) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
                [$peca['tipo'], $peca['nome'], $peca['x'], $peca['z'], $peca['largura'], $peca['profundidade'], $peca['rotacao'], $peca['inicio'], $peca['fim']]
            );
        }
        $pdo->commit();
    } catch (Throwable $erro) {
        $pdo->rollBack();
        throw $erro;
    }
}

function buscarSalaBruta(string $id): ?array
{
    return consultarUm('SELECT * FROM salas WHERE id = ?', [$id]);
}

/** Cria ($idExistente null) ou atualiza uma sala. Sala nova vai pro fim da ala. */
function salvarSala(?string $idExistente, array $dados): string
{
    $campos = [
        'nome' => $dados['nome'],
        'nome_curto' => $dados['nome_curto'],
        'funcao' => $dados['funcao'] ?: null,
        'andar_id' => $dados['andar_id'],
        'ala' => $dados['ala'],
        'lado' => $dados['ponta'] ? null : $dados['lado'],
        'ponta' => $dados['ponta'] ? 1 : 0,
        'vazia' => $dados['vazia'] ? 1 : 0,
        'setor_id' => $dados['setor_id'] ?: null,
    ];
    if ($idExistente === null) {
        $id = gerarIdLivre('salas', $dados['nome']);
        $campos['id'] = $id;
        $campos['ordem'] = (int) consultarValor('SELECT COALESCE(MAX(ordem), 0) + 1 FROM salas WHERE andar_id = ? AND ala = ?', [$dados['andar_id'], $dados['ala']]);
        $colunas = array_keys($campos);
        executar('INSERT INTO salas (' . implode(', ', $colunas) . ') VALUES (' . implode(', ', array_fill(0, count($colunas), '?')) . ')', array_values($campos));
        return $id;
    }
    $atual = buscarSalaBruta($idExistente);
    // Mudou de andar/ala: entra no fim da nova ala.
    if ($atual && ($atual['andar_id'] !== $dados['andar_id'] || $atual['ala'] !== $dados['ala'])) {
        $campos['ordem'] = (int) consultarValor('SELECT COALESCE(MAX(ordem), 0) + 1 FROM salas WHERE andar_id = ? AND ala = ?', [$dados['andar_id'], $dados['ala']]);
    }
    $sets = implode(', ', array_map(static function ($coluna) { return "{$coluna} = ?"; }, array_keys($campos)));
    executar("UPDATE salas SET {$sets} WHERE id = ?", array_merge(array_values($campos), [$idExistente]));
    return $idExistente;
}

function excluirSala(string $id): void
{
    executar('DELETE FROM salas WHERE id = ?', [$id]);
}

/**
 * Nova arrumação das salas vinda do arrasta-e-solta:
 * [['id' => 'cra', 'andar_id' => 'terreo', 'ala' => 'direita', 'ordem' => 1], ...]
 */
function reordenarSalas(array $posicoes): void
{
    $pdo = banco();
    $pdo->beginTransaction();
    try {
        foreach ($posicoes as $posicao) {
            executar('UPDATE salas SET andar_id = ?, ala = ?, ordem = ? WHERE id = ?', [$posicao['andar_id'], $posicao['ala'], $posicao['ordem'], $posicao['id']]);
        }
        $pdo->commit();
    } catch (Throwable $erro) {
        $pdo->rollBack();
        throw $erro;
    }
}

/* =============================================================
 * BUSCA "ONDE FICA..." (N1)
 * ============================================================= */

/** "Declaração  de Matrícula" -> "declaracao de matricula" (sem acento, minúsculo, espaços simples) */
function normalizarBusca(string $texto): string
{
    $texto = mb_strtolower(trim($texto), 'UTF-8');
    $texto = strtr($texto, [
        'á' => 'a', 'à' => 'a', 'â' => 'a', 'ã' => 'a', 'ä' => 'a', 'é' => 'e', 'ê' => 'e', 'è' => 'e', 'ë' => 'e',
        'í' => 'i', 'ì' => 'i', 'î' => 'i', 'ï' => 'i', 'ó' => 'o', 'ò' => 'o', 'ô' => 'o', 'õ' => 'o', 'ö' => 'o',
        'ú' => 'u', 'ù' => 'u', 'û' => 'u', 'ü' => 'u', 'ç' => 'c', 'ñ' => 'n',
    ]);
    return trim(preg_replace('/\s+/u', ' ', preg_replace('/[^\p{L}\p{N}\s-]/u', ' ', $texto)));
}

/** Palavras que não ajudam a achar nada ("onde fica a ..."). */
function palavrasVaziasBusca(): array
{
    return ['onde', 'fica', 'o', 'a', 'os', 'as', 'de', 'da', 'do', 'das', 'dos', 'e', 'em', 'no', 'na', 'um', 'uma', 'para', 'pra', 'como', 'que', 'quero', 'preciso', 'qual', 'setor', 'sala'];
}

/**
 * Procura setores pelo que a pessoa digitou. Cada palavra precisa aparecer em
 * algum lugar do setor (nome, sigla, sinônimo, serviço, pergunta do FAQ ou descrição).
 * Devolve até $limite resultados, do mais certeiro pro menos:
 *   ['id', 'nome', 'sigla', 'url', 'motivo', 'andar', 'sala_id', 'url_mapa']
 */
function buscarNoGuia(string $termo, int $limite = 8): array
{
    $termoNormal = normalizarBusca($termo);
    $palavras = array_values(array_filter(explode(' ', $termoNormal), static function ($palavra) {
        return mb_strlen($palavra) >= 2 && !in_array($palavra, palavrasVaziasBusca(), true);
    }));
    if (!$palavras) {
        return [];
    }

    // Tudo que dá pra buscar, por setor (são poucos setores: cabe na memória).
    $extras = [];
    foreach (consultar('SELECT setor_id, nome FROM setor_servicos') as $linha) {
        $extras[$linha['setor_id']]['servicos'][] = $linha['nome'];
    }
    foreach (consultar('SELECT setor_id, nome FROM sinonimos') as $linha) {
        $extras[$linha['setor_id']]['sinonimos'][] = $linha['nome'];
    }
    foreach (consultar('SELECT fs.setor_id, f.pergunta FROM faq f JOIN faq_setor fs ON fs.faq_id = f.id WHERE f.publicado = 1') as $linha) {
        $extras[$linha['setor_id']]['faq'][] = $linha['pergunta'];
    }
    $salaDoSetor = [];
    $mapa = listarMapaSalas();
    foreach ($mapa['salas'] as $sala) {
        if ($sala['setor_id'] && !isset($salaDoSetor[$sala['setor_id']])) {
            $salaDoSetor[$sala['setor_id']] = $sala;
        }
    }

    $resultados = [];
    foreach (listarSetores() as $setor) {
        $id = $setor['id'];
        // [peso, texto, como explicar o achado]
        $campos = [[100, $setor['sigla'], null, true], [60, $setor['nome'], null, false]];
        foreach ($extras[$id]['sinonimos'] ?? [] as $sinonimo) {
            $campos[] = [80, $sinonimo, 'Também procurado como "' . $sinonimo . '"', false];
        }
        foreach ($extras[$id]['servicos'] ?? [] as $servico) {
            $campos[] = [40, $servico, 'Serviço: ' . $servico, false];
        }
        foreach ($extras[$id]['faq'] ?? [] as $pergunta) {
            $campos[] = [30, $pergunta, 'Pergunta: ' . $pergunta, false];
        }
        $campos[] = [15, (string) $setor['descricao'] . ' ' . (string) $setor['descricao_curta'], null, false];

        $pontos = 0;
        $motivo = null;
        foreach ($palavras as $palavra) {
            $melhor = 0;
            foreach ($campos as [$peso, $texto, $explicacao, $soInteiro]) {
                $textoNormal = normalizarBusca((string) $texto);
                if ($textoNormal === '') {
                    continue;
                }
                $achou = $soInteiro ? $textoNormal === $palavra : (strpos(' ' . $textoNormal . ' ', ' ' . $palavra) !== false);
                if (!$achou && !$soInteiro && mb_strlen($palavra) >= 4) {
                    $achou = strpos($textoNormal, $palavra) !== false; // pedaço no meio da palavra
                    $peso = (int) ($peso / 2);
                }
                if ($achou && $peso > $melhor) {
                    $melhor = $peso;
                    if ($explicacao && $peso >= 30) {
                        $motivo = $motivo ?? $explicacao;
                    }
                }
            }
            if ($melhor === 0) {
                continue 2; // uma palavra não achou nada: setor fora
            }
            $pontos += $melhor;
        }

        $sala = $salaDoSetor[$id] ?? null;
        $resultados[] = [
            'id' => $id,
            'nome' => $setor['nome'],
            'sigla' => $setor['sigla'],
            'url' => 'setor.php?id=' . rawurlencode($id),
            'motivo' => $motivo,
            'andar' => $sala ? ($mapa['andares'][$sala['andar']]['nome'] ?? '') : null,
            'sala_id' => $sala['id'] ?? null,
            'url_mapa' => $sala ? 'mapa.php?sala=' . rawurlencode($sala['id']) : null,
            'pontos' => $pontos,
        ];
    }

    // Nenhum setor tem TODAS as palavras: tenta com cada palavra sozinha
    // ("empréstimo de livro" ainda acha a Biblioteca pelo "empréstimo").
    if (!$resultados && count($palavras) > 1) {
        $porId = [];
        foreach ($palavras as $palavra) {
            foreach (buscarNoGuia($palavra, $limite) as $achado) {
                if (!isset($porId[$achado['id']]) || $porId[$achado['id']]['pontos'] < $achado['pontos']) {
                    $porId[$achado['id']] = $achado;
                }
            }
        }
        $resultados = array_values($porId);
    }

    usort($resultados, static function ($a, $b) {
        return $b['pontos'] <=> $a['pontos'] ?: strcmp($a['nome'], $b['nome']);
    });
    return array_slice($resultados, 0, $limite);
}

/* =============================================================
 * QR DA PORTA (N2): cada sala tem um endereço que abre a página
 * dela já sabendo que a pessoa "está aqui".
 * ============================================================= */

/** Endereço completo que vai no QR da porta da sala. */
function urlDaPorta(array $sala): string
{
    $caminho = $sala['url_setor']
        ? $sala['url_setor'] . '&aqui=' . rawurlencode($sala['id'])
        : 'sala.php?id=' . rawurlencode($sala['id']) . '&aqui=1';
    return urlBaseSite() . '/' . $caminho;
}

/* =============================================================
 * AVISOS, NOTÍCIAS E CALENDÁRIO (N6) + "HOJE NO CAMPUS" (N5)
 * ============================================================= */

/** Avisos publicados que valem agora (dentro do período, se tiver). Urgentes primeiro. */
function listarAvisosAtivos(): array
{
    return consultar(
        "SELECT id, titulo, mensagem, nivel, inicio, fim FROM avisos
          WHERE publicado = 1 AND (inicio IS NULL OR inicio <= NOW()) AND (fim IS NULL OR fim >= NOW())
          ORDER BY nivel = 'urgente' DESC, ordem, id DESC"
    );
}

/** O aviso urgente que vira faixa no topo do site (ou null). */
function avisoUrgenteAtual(): ?array
{
    foreach (listarAvisosAtivos() as $aviso) {
        if ($aviso['nivel'] === 'urgente') {
            return $aviso;
        }
    }
    return null;
}

function buscarNoticiaPorSlug(string $slug): ?array
{
    $noticia = consultarUm('SELECT * FROM noticias WHERE slug = ? AND publicado = 1', [$slug]);
    if ($noticia) {
        $noticia['data'] = formatarDataCurta($noticia['publicada_em']);
    }
    return $noticia;
}

/** Eventos publicados a partir de uma data (calendário), em ordem. */
function listarEventos(?string $aPartirDe = null, int $limite = 200): array
{
    return consultar(
        'SELECT id, titulo, descricao, inicio, fim, tipo, periodo_letivo FROM eventos
          WHERE publicado = 1 AND COALESCE(fim, inicio) >= ?
          ORDER BY inicio, ordem, id LIMIT ' . max(1, $limite),
        [$aPartirDe ?? '1900-01-01']
    );
}

function buscarEvento(int $id): ?array
{
    return consultarUm('SELECT * FROM eventos WHERE id = ? AND publicado = 1', [$id]);
}

/** Eventos que acontecem num dia. */
function eventosDoDia(string $data): array
{
    return consultar(
        'SELECT id, titulo, tipo FROM eventos WHERE publicado = 1 AND inicio <= ? AND COALESCE(fim, inicio) >= ? ORDER BY ordem, id',
        [$data, $data]
    );
}

function proximoEvento(string $depoisDe): ?array
{
    return consultarUm(
        'SELECT id, titulo, tipo, inicio, fim FROM eventos WHERE publicado = 1 AND inicio > ? ORDER BY inicio, ordem LIMIT 1',
        [$depoisDe]
    );
}

/**
 * Tudo da faixa "Hoje no campus" da home.
 * Não inventa "dia letivo": só diz o que o calendário cadastrado informa.
 */
function hojeNoCampus(?DateTimeImmutable $agora = null): array
{
    $agora = $agora ?? new DateTimeImmutable('now');
    $hoje = $agora->format('Y-m-d');
    $diaSemana = (int) $agora->format('w');
    $meses = ['janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho', 'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro'];
    $dataPorExtenso = ucfirst(NOMES_DIAS[$diaSemana]) . ', ' . (int) $agora->format('j') . ' de ' . $meses[(int) $agora->format('n') - 1];

    $eventosHoje = eventosDoDia($hoje);
    $situacao = null;
    foreach ($eventosHoje as $evento) {
        if (in_array($evento['tipo'], ['feriado', 'recesso'], true)) {
            $situacao = ['tipo' => $evento['tipo'], 'texto' => ucfirst($evento['tipo']) . ': ' . $evento['titulo']];
        }
    }
    if (!$situacao && ($diaSemana === 0 || $diaSemana === 6)) {
        $situacao = ['tipo' => 'fim_de_semana', 'texto' => 'Fim de semana'];
    }

    $abertos = [];
    $comHorario = 0;
    foreach (listarSetores() as $setor) {
        $estado = estadoHorarioSetor($setor, $agora);
        if ($estado['aberto'] !== null) {
            $comHorario++;
        }
        if ($estado['aberto'] === true) {
            $abertos[] = ['id' => $setor['id'], 'nome' => $setor['nome'], 'sigla' => $setor['sigla'], 'resumo' => $estado['resumo']];
        }
    }

    return [
        'data' => $dataPorExtenso,
        'situacao' => $situacao,
        'eventos_hoje' => $eventosHoje,
        'abertos' => $abertos,
        'setores_com_horario' => $comHorario,
        'proximo_evento' => proximoEvento($hoje),
        'aviso_urgente' => avisoUrgenteAtual(),
        'atualizado_em' => $agora->format('H:i'),
    ];
}

/* =============================================================
 * "COMO FAÇO PARA..." (N11)
 * ============================================================= */

function listarFluxos(bool $incluirOcultos = false): array
{
    return consultar(
        'SELECT f.*, s.nome AS setor_nome, s.sigla AS setor_sigla FROM fluxos f LEFT JOIN setores s ON s.id = f.setor_id
          WHERE f.publicado = 1 OR :todos = 1 ORDER BY f.ordem, f.titulo',
        ['todos' => $incluirOcultos ? 1 : 0]
    );
}

/** Fluxo completo (com passos e documentos) por slug ou id. */
function buscarFluxo(string $slugOuId, bool $incluirOculto = false): ?array
{
    $fluxo = consultarUm(
        'SELECT f.*, s.nome AS setor_nome, s.sigla AS setor_sigla FROM fluxos f LEFT JOIN setores s ON s.id = f.setor_id
          WHERE f.slug = ? OR f.id = ?',
        [$slugOuId, ctype_digit($slugOuId) ? (int) $slugOuId : 0]
    );
    if (!$fluxo || (!$incluirOculto && !(int) $fluxo['publicado'])) {
        return null;
    }
    $fluxo['passos'] = array_column(consultar('SELECT nome FROM fluxo_passos WHERE fluxo_id = ? ORDER BY ordem, id', [$fluxo['id']]), 'nome');
    $fluxo['documentos'] = array_column(consultar('SELECT nome FROM fluxo_documentos WHERE fluxo_id = ? ORDER BY ordem, id', [$fluxo['id']]), 'nome');
    return $fluxo;
}

/** Cria ($id null) ou atualiza um fluxo com passos e documentos. Devolve o id. */
function salvarFluxo(?int $id, array $dados): int
{
    $pdo = banco();
    $pdo->beginTransaction();
    try {
        $campos = [$dados['titulo'], $dados['resumo'] ?: null, $dados['setor_id'] ?: null, $dados['canal'] ?: null, $dados['prazo'] ?: null, $dados['publicado'] ? 1 : 0];
        if ($id === null) {
            executar(
                'INSERT INTO fluxos (titulo, resumo, setor_id, canal, prazo, publicado, slug, ordem) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
                array_merge($campos, [gerarIdLivre('fluxos', $dados['titulo'], 'slug'), (int) consultarValor('SELECT COALESCE(MAX(ordem), 0) + 1 FROM fluxos')])
            );
            $id = (int) $pdo->lastInsertId();
        } else {
            executar('UPDATE fluxos SET titulo = ?, resumo = ?, setor_id = ?, canal = ?, prazo = ?, publicado = ? WHERE id = ?', array_merge($campos, [$id]));
        }
        foreach (['fluxo_passos' => 'passos', 'fluxo_documentos' => 'documentos'] as $tabela => $chave) {
            executar("DELETE FROM {$tabela} WHERE fluxo_id = ?", [$id]);
            foreach (array_values($dados[$chave]) as $posicao => $nome) {
                executar("INSERT INTO {$tabela} (fluxo_id, nome, ordem) VALUES (?, ?, ?)", [$id, $nome, $posicao]);
            }
        }
        $pdo->commit();
        return $id;
    } catch (Throwable $erro) {
        $pdo->rollBack();
        throw $erro;
    }
}

function excluirFluxo(int $id): void
{
    executar('DELETE FROM fluxos WHERE id = ?', [$id]);
}

function alternarFluxoPublicado(int $id): void
{
    executar('UPDATE fluxos SET publicado = 1 - publicado WHERE id = ?', [$id]);
}

/* =============================================================
 * ACESSIBILIDADE FÍSICA DAS SALAS (I3)
 * Cada item: 1 = tem, 0 = não tem, NULL = não informado (nada é presumido).
 * ============================================================= */

function itensAcessibilidadeSala(): array
{
    return [
        'rampa' => 'Rampa ou acesso sem degrau',
        'elevador' => 'Chega de elevador',
        'banheiro_adaptado' => 'Banheiro adaptado perto',
        'balcao_baixo' => 'Balcão de atendimento baixo',
        'piso_tatil' => 'Piso tátil até a porta',
        'porta_larga' => 'Porta larga (cadeira de rodas)',
    ];
}

/** Dados de acessibilidade de uma sala (todos NULL = não informado quando não há cadastro). */
function buscarAcessibilidadeSala(string $idSala): array
{
    $linha = consultarUm('SELECT * FROM acessibilidade_sala WHERE sala_id = ?', [$idSala]) ?? [];
    $dados = [];
    foreach (array_keys(itensAcessibilidadeSala()) as $item) {
        $dados[$item] = isset($linha[$item]) ? (int) $linha[$item] : null;
    }
    $dados['observacao'] = $linha['observacao'] ?? null;
    return $dados;
}

function salvarAcessibilidadeSala(string $idSala, array $dados): void
{
    $itens = array_keys(itensAcessibilidadeSala());
    $valores = array_map(static function ($item) use ($dados) { return $dados[$item]; }, $itens);
    executar(
        'INSERT INTO acessibilidade_sala (sala_id, ' . implode(', ', $itens) . ', observacao) VALUES (?, ' . implode(', ', array_fill(0, count($itens), '?')) . ', ?)
         ON DUPLICATE KEY UPDATE ' . implode(', ', array_map(static function ($item) { return "{$item} = VALUES({$item})"; }, $itens)) . ', observacao = VALUES(observacao)',
        array_merge([$idSala], $valores, [$dados['observacao'] ?: null])
    );
}

/** Mapa sala_id => true quando a sala é acessível sem escada (térreo ou elevador informado). */
function salasSemEscada(): array
{
    $comElevador = array_column(consultar('SELECT sala_id FROM acessibilidade_sala WHERE elevador = 1'), 'sala_id', 'sala_id');
    $resultado = [];
    foreach (listarMapaSalas()['salas'] as $sala) {
        $resultado[$sala['id']] = $sala['andar'] === 'terreo' || isset($comElevador[$sala['id']]);
    }
    return $resultado;
}

/* =============================================================
 * TRADUÇÕES (I6) — rascunho -> revisado -> publicado
 * ============================================================= */

/** Traduções PUBLICADAS de um idioma, por "entidade|id|campo". Lidas uma vez por requisição. */
function traducoesPublicadas(string $idioma): array
{
    static $cache = [];
    if (!isset($cache[$idioma])) {
        $cache[$idioma] = [];
        foreach (consultar("SELECT entidade, entidade_id, campo, texto, audio_url, pictograma FROM traducoes WHERE idioma = ? AND status = 'publicado'", [$idioma]) as $linha) {
            $cache[$idioma][$linha['entidade'] . '|' . $linha['entidade_id'] . '|' . $linha['campo']] = $linha;
        }
    }
    return $cache[$idioma];
}

function contarTraducoesPublicadas(string $idioma): int
{
    static $cache = [];
    if (!isset($cache[$idioma])) {
        $cache[$idioma] = (int) consultarValor("SELECT COUNT(*) FROM traducoes WHERE idioma = ? AND status = 'publicado'", [$idioma]);
    }
    return $cache[$idioma];
}

/** Todas as traduções de um idioma (qualquer status), por "entidade|id|campo" — pro admin. */
function listarTraducoesDoIdioma(string $idioma): array
{
    $porChave = [];
    foreach (consultar('SELECT * FROM traducoes WHERE idioma = ?', [$idioma]) as $linha) {
        $porChave[$linha['entidade'] . '|' . $linha['entidade_id'] . '|' . $linha['campo']] = $linha;
    }
    return $porChave;
}

/** Cria ou atualiza uma tradução. Quem chama decide o status (e confere as regras do fluxo). */
function salvarTraducao(string $entidade, string $idEntidade, string $campo, string $idioma, array $dados): void
{
    executar(
        'INSERT INTO traducoes (entidade, entidade_id, campo, idioma, texto, status, validado_por, validado_em, audio_url, pictograma)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE texto = VALUES(texto), status = VALUES(status), validado_por = VALUES(validado_por),
                                 validado_em = VALUES(validado_em), audio_url = VALUES(audio_url), pictograma = VALUES(pictograma)',
        [$entidade, $idEntidade, $campo, $idioma, $dados['texto'], $dados['status'], $dados['validado_por'] ?: null,
            $dados['validado_em'] ?: null, $dados['audio_url'] ?: null, $dados['pictograma'] ?: null]
    );
}

function buscarTraducao(string $entidade, string $idEntidade, string $campo, string $idioma): ?array
{
    return consultarUm('SELECT * FROM traducoes WHERE entidade = ? AND entidade_id = ? AND campo = ? AND idioma = ?', [$entidade, $idEntidade, $campo, $idioma]);
}
