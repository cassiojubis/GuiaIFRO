<?php
/**
 * IDIOMAS DO SITE (I6)
 *
 * O português fica aqui no código (é o texto original). Espanhol e Oro Wari
 * vêm da tabela `traducoes`, e só aparece no site o que está PUBLICADO.
 * Faltou tradução? Mostra o português (nunca deixa a tela vazia).
 *
 * Fluxo de cada tradução (admin › Traduções): rascunho -> revisado -> publicado.
 * Oro Wari: só pode ser publicado depois de revisado por falante da língua;
 * enquanto não houver nada publicado, a opção mostra o aviso explicando isso.
 */

require_once __DIR__ . '/Repositorio.php';

$idiomasDisponiveis = [
    'pt' => ['nome' => 'Português', 'bandeira' => '🇧🇷', 'html' => 'pt-BR'],
    'es' => ['nome' => 'Español', 'bandeira' => '🇪🇸', 'html' => 'es'],
    'wari' => ['nome' => 'Oro Wari (Pakaa Nova)', 'bandeira' => '🌿', 'html' => 'pnv'],
];

/** Textos da interface em português (a fonte de tudo). Chave => texto. */
const TEXTOS_INTERFACE_PT = [
    'nav_inicio' => 'Início',
    'nav_categorias' => 'Categorias',
    'nav_mapa' => 'Mapa',
    'nav_sobre' => 'Sobre',
    'nav_contato' => 'Contato',
    'busca_placeholder' => 'Buscar setor...',
    'btn_fale_conosco' => 'Fale conosco',
    'rodape_navegacao' => 'Navegação',
    'rodape_direitos' => 'Todos os direitos reservados.',
    'rodape_acessibilidade' => 'Acessibilidade',
];

/** O idioma pode ser escolhido? Oro Wari só quando houver algo validado e publicado. */
function idiomaPodeSerUsado(string $codigo): bool
{
    if ($codigo === 'pt' || $codigo === 'es') {
        return true;
    }
    return $codigo === 'wari' && contarTraducoesPublicadas('wari') > 0;
}

/** Idioma atual da sessão (padrão: português). */
function idiomaAtual(): string
{
    $idioma = (string) ($_SESSION['idioma'] ?? 'pt');
    return idiomaPodeSerUsado($idioma) ? $idioma : 'pt';
}

/** Valor do atributo lang do <html> pro idioma atual. */
function idiomaHtml(): string
{
    return $GLOBALS['idiomasDisponiveis'][idiomaAtual()]['html'] ?? 'pt-BR';
}

/** Texto da interface no idioma atual (ou em português, se faltar). */
function t(string $chave): string
{
    $padrao = TEXTOS_INTERFACE_PT[$chave] ?? $chave;
    $idioma = idiomaAtual();
    if ($idioma === 'pt') {
        return $padrao;
    }
    return traducoesPublicadas($idioma)['interface||' . $chave]['texto'] ?? $padrao;
}

/**
 * Conteúdo (nome/descrição de setor...) no idioma atual, ou o original em português.
 * Ex.: traduzirConteudo('setor', 'cra', 'descricao', $setor['descricao'])
 */
function traduzirConteudo(string $entidade, string $idEntidade, string $campo, ?string $textoPt): ?string
{
    $idioma = idiomaAtual();
    if ($idioma === 'pt' || $textoPt === null || $textoPt === '') {
        return $textoPt;
    }
    return traducoesPublicadas($idioma)["{$entidade}|{$idEntidade}|{$campo}"]['texto'] ?? $textoPt;
}

/** Áudio gravado (ex.: por falante de Oro Wari) de um conteúdo no idioma atual, se houver. */
function audioDoConteudo(string $entidade, string $idEntidade, string $campo): ?string
{
    $idioma = idiomaAtual();
    if ($idioma === 'pt') {
        return null;
    }
    $traducao = traducoesPublicadas($idioma)["{$entidade}|{$idEntidade}|{$campo}"] ?? null;
    return $traducao['audio_url'] ?? null;
}
