-- =============================================================
-- BANCO DO GUIA IFRO (MariaDB 10.4+ / MySQL 8)
-- Desenho das tabelas em docs/BANCO.md.
-- Pode rodar de novo sem medo: tudo é "IF NOT EXISTS".
-- Quem roda isso é o bin/instalar-banco.php (com um usuário que pode criar tabela).
-- =============================================================

SET NAMES utf8mb4;

-- ---------- MODELO PRINCIPAL: categoria -> setor -> sala ----------

CREATE TABLE IF NOT EXISTS categorias (
    id          VARCHAR(60)  NOT NULL,
    nome        VARCHAR(150) NOT NULL,
    icone       VARCHAR(60)  NOT NULL DEFAULT 'shapes',
    cor         VARCHAR(20)  NOT NULL DEFAULT 'green',
    ordem       INT          NOT NULL DEFAULT 0,
    ativo       TINYINT(1)   NOT NULL DEFAULT 1,
    atualizado_em DATETIME   NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS setores (
    id              VARCHAR(60)  NOT NULL,
    categoria_id    VARCHAR(60)  NULL,
    nome            VARCHAR(200) NOT NULL,
    sigla           VARCHAR(30)  NOT NULL DEFAULT '',
    icone           VARCHAR(60)  NOT NULL DEFAULT 'building-2',
    cor             VARCHAR(20)  NOT NULL DEFAULT 'green',
    descricao       TEXT         NULL,
    descricao_curta VARCHAR(255) NULL,
    texto_facil     TEXT         NULL COMMENT 'versão em Leitura Fácil (I4)',
    localizacao     VARCHAR(255) NULL,
    bloco           VARCHAR(150) NULL,
    sala_texto      VARCHAR(150) NULL,
    telefone        VARCHAR(60)  NULL,
    email           VARCHAR(150) NULL,
    responsavel     VARCHAR(150) NULL,
    video           VARCHAR(255) NULL,
    horario_texto   VARCHAR(255) NULL COMMENT 'só observação; o horário de verdade fica em setor_horarios',
    ordem           INT          NOT NULL DEFAULT 0,
    ativo           TINYINT(1)   NOT NULL DEFAULT 1,
    fila_status     VARCHAR(20)  NULL COMMENT 'tranquilo / movimentado / cheio (W5)',
    fila_atualizada_em DATETIME  NULL,
    atualizado_em   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    atualizado_por  VARCHAR(150) NULL,
    PRIMARY KEY (id),
    KEY idx_setores_categoria (categoria_id),
    CONSTRAINT fk_setores_categoria FOREIGN KEY (categoria_id) REFERENCES categorias (id)
        ON UPDATE CASCADE ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS setor_equipe (
    id        INT UNSIGNED NOT NULL AUTO_INCREMENT,
    setor_id  VARCHAR(60)  NOT NULL,
    nome      VARCHAR(150) NOT NULL,
    cargo     VARCHAR(100) NULL,
    ordem     INT          NOT NULL DEFAULT 0,
    PRIMARY KEY (id),
    KEY idx_equipe_setor (setor_id),
    CONSTRAINT fk_equipe_setor FOREIGN KEY (setor_id) REFERENCES setores (id) ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS setor_servicos (
    id        INT UNSIGNED NOT NULL AUTO_INCREMENT,
    setor_id  VARCHAR(60)  NOT NULL,
    nome      VARCHAR(255) NOT NULL,
    ordem     INT          NOT NULL DEFAULT 0,
    PRIMARY KEY (id),
    KEY idx_servicos_setor (setor_id),
    CONSTRAINT fk_servicos_setor FOREIGN KEY (setor_id) REFERENCES setores (id) ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS setor_documentos (
    id        INT UNSIGNED NOT NULL AUTO_INCREMENT,
    setor_id  VARCHAR(60)  NOT NULL,
    nome      VARCHAR(255) NOT NULL,
    arquivo   VARCHAR(255) NULL COMMENT 'caminho do PDF, quando houver',
    ordem     INT          NOT NULL DEFAULT 0,
    PRIMARY KEY (id),
    KEY idx_documentos_setor (setor_id),
    CONSTRAINT fk_documentos_setor FOREIGN KEY (setor_id) REFERENCES setores (id) ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- dia_semana: 0 = domingo ... 6 = sábado (igual ao date('w') do PHP)
CREATE TABLE IF NOT EXISTS setor_horarios (
    id          INT UNSIGNED NOT NULL AUTO_INCREMENT,
    setor_id    VARCHAR(60)  NOT NULL,
    dia_semana  TINYINT      NOT NULL,
    abre        TIME         NOT NULL,
    fecha       TIME         NOT NULL,
    observacao  VARCHAR(150) NULL,
    PRIMARY KEY (id),
    KEY idx_horarios_setor_dia (setor_id, dia_semana),
    CONSTRAINT fk_horarios_setor FOREIGN KEY (setor_id) REFERENCES setores (id) ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Feriados, recessos e dias especiais. setor_id NULL = vale para o campus todo.
-- fechado = 1: fechado o dia inteiro. fechado = 0 com abre/fecha: horário especial.
CREATE TABLE IF NOT EXISTS setor_excecoes (
    id        INT UNSIGNED NOT NULL AUTO_INCREMENT,
    setor_id  VARCHAR(60)  NULL,
    data      DATE         NOT NULL,
    fechado   TINYINT(1)   NOT NULL DEFAULT 1,
    abre      TIME         NULL,
    fecha     TIME         NULL,
    motivo    VARCHAR(150) NOT NULL,
    PRIMARY KEY (id),
    KEY idx_excecoes_data (data),
    KEY idx_excecoes_setor (setor_id),
    CONSTRAINT fk_excecoes_setor FOREIGN KEY (setor_id) REFERENCES setores (id) ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS andares (
    id     VARCHAR(20) NOT NULL,
    nome   VARCHAR(60) NOT NULL,
    ordem  INT         NOT NULL DEFAULT 0,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Salas do prédio. Sem coordenadas: o js/mapa.js calcula o desenho a partir de ala/ordem/lado/ponta.
-- Ordem dentro de cada ala: 1 = mais perto da escada. lado NULL nas pontas.
CREATE TABLE IF NOT EXISTS salas (
    id          VARCHAR(60)  NOT NULL,
    nome        VARCHAR(150) NOT NULL,
    nome_curto  VARCHAR(60)  NOT NULL,
    funcao      VARCHAR(255) NULL COMMENT 'para a ficha simples de sala sem setor',
    andar_id    VARCHAR(20)  NOT NULL,
    ala         ENUM('esquerda','direita') NOT NULL,
    ordem       INT          NOT NULL,
    lado        ENUM('frente','fundos') NULL,
    ponta       TINYINT(1)   NOT NULL DEFAULT 0,
    vazia       TINYINT(1)   NOT NULL DEFAULT 0 COMMENT 'espaço vazio (só ocupa lugar no desenho)',
    setor_id    VARCHAR(60)  NULL,
    PRIMARY KEY (id),
    KEY idx_salas_andar (andar_id, ala, ordem),
    KEY idx_salas_setor (setor_id),
    CONSTRAINT fk_salas_andar FOREIGN KEY (andar_id) REFERENCES andares (id) ON UPDATE CASCADE,
    CONSTRAINT fk_salas_setor FOREIGN KEY (setor_id) REFERENCES setores (id) ON UPDATE CASCADE ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Acessibilidade física de cada sala (I3). NULL = não informado.
CREATE TABLE IF NOT EXISTS acessibilidade_sala (
    sala_id            VARCHAR(60) NOT NULL,
    rampa              TINYINT(1)  NULL,
    elevador           TINYINT(1)  NULL,
    banheiro_adaptado  TINYINT(1)  NULL,
    balcao_baixo       TINYINT(1)  NULL,
    piso_tatil         TINYINT(1)  NULL,
    porta_larga        TINYINT(1)  NULL,
    observacao         VARCHAR(255) NULL,
    atualizado_em      DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (sala_id),
    CONSTRAINT fk_acess_sala FOREIGN KEY (sala_id) REFERENCES salas (id) ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Cenário em volta do prédio (B6). x/z em metros a partir do centro da entrada.
-- inicio/fim preenchidos = peça temporária (W3: estande, obra, evento).
CREATE TABLE IF NOT EXISTS pecas_mapa (
    id            INT UNSIGNED NOT NULL AUTO_INCREMENT,
    tipo          VARCHAR(30)  NOT NULL,
    nome          VARCHAR(150) NOT NULL DEFAULT '',
    x             DECIMAL(7,2) NOT NULL DEFAULT 0,
    z             DECIMAL(7,2) NOT NULL DEFAULT 0,
    largura       DECIMAL(7,2) NOT NULL DEFAULT 4,
    profundidade  DECIMAL(7,2) NOT NULL DEFAULT 4,
    rotacao       DECIMAL(6,2) NOT NULL DEFAULT 0,
    inicio        DATETIME     NULL,
    fim           DATETIME     NULL,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------- CONTEÚDO ----------

CREATE TABLE IF NOT EXISTS avisos (
    id         INT UNSIGNED NOT NULL AUTO_INCREMENT,
    titulo     VARCHAR(200) NOT NULL,
    mensagem   TEXT         NOT NULL,
    nivel      ENUM('normal','urgente') NOT NULL DEFAULT 'normal',
    inicio     DATETIME     NULL,
    fim        DATETIME     NULL,
    publicado  TINYINT(1)   NOT NULL DEFAULT 1,
    ordem      INT          NOT NULL DEFAULT 0,
    criado_em  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_avisos_periodo (publicado, inicio, fim)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS noticias (
    id            INT UNSIGNED NOT NULL AUTO_INCREMENT,
    slug          VARCHAR(160) NOT NULL,
    titulo        VARCHAR(200) NOT NULL,
    resumo        VARCHAR(400) NULL,
    conteudo      TEXT         NULL,
    categoria     VARCHAR(60)  NULL,
    publicada_em  DATE         NOT NULL,
    destaque      TINYINT(1)   NOT NULL DEFAULT 0,
    publicado     TINYINT(1)   NOT NULL DEFAULT 1,
    ordem         INT          NOT NULL DEFAULT 0,
    PRIMARY KEY (id),
    UNIQUE KEY uq_noticias_slug (slug),
    KEY idx_noticias_data (publicado, publicada_em)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS eventos (
    id              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    titulo          VARCHAR(200) NOT NULL,
    descricao       TEXT         NULL,
    inicio          DATE         NOT NULL,
    fim             DATE         NULL,
    tipo            ENUM('evento','feriado','recesso','letivo','prova') NOT NULL DEFAULT 'evento',
    periodo_letivo  VARCHAR(20)  NULL,
    local_sala_id   VARCHAR(60)  NULL,
    publicado       TINYINT(1)   NOT NULL DEFAULT 1,
    ordem           INT          NOT NULL DEFAULT 0,
    PRIMARY KEY (id),
    KEY idx_eventos_data (publicado, inicio)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS faq (
    id         INT UNSIGNED NOT NULL AUTO_INCREMENT,
    pergunta   VARCHAR(300) NOT NULL,
    resposta   TEXT         NOT NULL,
    publicado  TINYINT(1)   NOT NULL DEFAULT 1,
    ordem      INT          NOT NULL DEFAULT 0,
    atualizado_em DATETIME  NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Liga uma pergunta a um ou mais setores. Pergunta sem ligação = FAQ geral.
CREATE TABLE IF NOT EXISTS faq_setor (
    faq_id    INT UNSIGNED NOT NULL,
    setor_id  VARCHAR(60)  NOT NULL,
    PRIMARY KEY (faq_id, setor_id),
    KEY idx_faq_setor_setor (setor_id),
    CONSTRAINT fk_faqsetor_faq FOREIGN KEY (faq_id) REFERENCES faq (id) ON DELETE CASCADE,
    CONSTRAINT fk_faqsetor_setor FOREIGN KEY (setor_id) REFERENCES setores (id) ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS links_uteis (
    id         INT UNSIGNED NOT NULL AUTO_INCREMENT,
    titulo     VARCHAR(150) NOT NULL,
    url        VARCHAR(255) NOT NULL,
    publicado  TINYINT(1)   NOT NULL DEFAULT 1,
    ordem      INT          NOT NULL DEFAULT 0,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS textos_institucionais (
    id         INT UNSIGNED NOT NULL AUTO_INCREMENT,
    titulo     VARCHAR(150) NOT NULL,
    conteudo   TEXT         NOT NULL,
    publicado  TINYINT(1)   NOT NULL DEFAULT 1,
    ordem      INT          NOT NULL DEFAULT 0,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS atalhos_home (
    id         INT UNSIGNED NOT NULL AUTO_INCREMENT,
    titulo     VARCHAR(80)  NOT NULL,
    descricao  VARCHAR(120) NOT NULL DEFAULT '',
    icone      VARCHAR(60)  NOT NULL DEFAULT 'building-2',
    cor        VARCHAR(20)  NOT NULL DEFAULT 'green',
    url        VARCHAR(255) NOT NULL,
    ordem      INT          NOT NULL DEFAULT 0,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Configurações editáveis no admin (contato geral, redes sociais, link do WhatsApp...)
CREATE TABLE IF NOT EXISTS configuracoes (
    chave  VARCHAR(80) NOT NULL,
    valor  TEXT        NULL,
    PRIMARY KEY (chave)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------- USUÁRIOS E PERMISSÕES ----------

CREATE TABLE IF NOT EXISTS perfis (
    id    VARCHAR(30) NOT NULL,
    nome  VARCHAR(80) NOT NULL,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS usuarios (
    id               INT UNSIGNED NOT NULL AUTO_INCREMENT,
    nome             VARCHAR(150) NOT NULL,
    usuario          VARCHAR(60)  NOT NULL,
    email            VARCHAR(150) NULL,
    senha_hash       VARCHAR(255) NOT NULL,
    perfil_id        VARCHAR(30)  NOT NULL,
    ativo            TINYINT(1)   NOT NULL DEFAULT 1,
    sessao_versao    INT UNSIGNED NOT NULL DEFAULT 1 COMMENT 'aumentar desloga todos os aparelhos',
    ultimo_login_em  DATETIME     NULL,
    criado_em        DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_usuarios_usuario (usuario),
    UNIQUE KEY uq_usuarios_email (email),
    CONSTRAINT fk_usuarios_perfil FOREIGN KEY (perfil_id) REFERENCES perfis (id) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS usuario_setor (
    usuario_id  INT UNSIGNED NOT NULL,
    setor_id    VARCHAR(60)  NOT NULL,
    PRIMARY KEY (usuario_id, setor_id),
    KEY idx_usuario_setor_setor (setor_id),
    CONSTRAINT fk_ususetor_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios (id) ON DELETE CASCADE,
    CONSTRAINT fk_ususetor_setor FOREIGN KEY (setor_id) REFERENCES setores (id) ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------- REGISTROS ----------

-- Limite de envios/tentativas (contato e login).
-- chave_hash = hash do IP (ou usuário+IP) com sal: não dá pra saber o IP olhando a tabela.
CREATE TABLE IF NOT EXISTS limites (
    id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    acao        VARCHAR(40)  NOT NULL,
    chave_hash  CHAR(64)     NOT NULL,
    criado_em   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_limites_busca (acao, chave_hash, criado_em)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS auditoria (
    id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    usuario_id    INT UNSIGNED NULL,
    usuario_nome  VARCHAR(150) NOT NULL,
    acao          VARCHAR(30)  NOT NULL COMMENT 'criar, editar, excluir, ativar, desativar...',
    tabela        VARCHAR(60)  NOT NULL,
    registro_id   VARCHAR(60)  NULL,
    resumo        VARCHAR(255) NULL,
    antes         LONGTEXT     NULL COMMENT 'JSON',
    depois        LONGTEXT     NULL COMMENT 'JSON',
    quando        DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_auditoria_quando (quando),
    KEY idx_auditoria_registro (tabela, registro_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS contatos_mensagens (
    id         INT UNSIGNED NOT NULL AUTO_INCREMENT,
    nome       VARCHAR(150) NOT NULL,
    email      VARCHAR(150) NOT NULL,
    telefone   VARCHAR(40)  NULL,
    assunto    VARCHAR(100) NOT NULL,
    mensagem   TEXT         NOT NULL,
    email_enviado TINYINT(1) NOT NULL DEFAULT 0,
    criada_em  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    lida_em    DATETIME     NULL,
    PRIMARY KEY (id),
    KEY idx_contatos_criada (criada_em)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Traduções de conteúdo (I6). status: rascunho -> revisado -> publicado.
-- Oro Wari só aparece no site quando status = publicado (validado por falante).
CREATE TABLE IF NOT EXISTS traducoes (
    id            INT UNSIGNED NOT NULL AUTO_INCREMENT,
    entidade      VARCHAR(40)  NOT NULL COMMENT 'interface, setor, sala, faq...',
    entidade_id   VARCHAR(60)  NOT NULL DEFAULT '',
    campo         VARCHAR(60)  NOT NULL,
    idioma        VARCHAR(10)  NOT NULL,
    texto         TEXT         NOT NULL,
    status        ENUM('rascunho','revisado','publicado') NOT NULL DEFAULT 'rascunho',
    validado_por  VARCHAR(150) NULL,
    validado_em   DATETIME     NULL,
    audio_url     VARCHAR(255) NULL,
    pictograma    VARCHAR(120) NULL COMMENT 'ícone do Lucide ou caminho de imagem',
    atualizado_em DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_traducao (entidade, entidade_id, campo, idioma)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Sinônimos da busca (N1): "declaração" acha o CRA, "auxílio" acha a CAED...
CREATE TABLE IF NOT EXISTS sinonimos (
    id        INT UNSIGNED NOT NULL AUTO_INCREMENT,
    setor_id  VARCHAR(60)  NOT NULL,
    nome      VARCHAR(100) NOT NULL,
    ordem     INT          NOT NULL DEFAULT 0,
    PRIMARY KEY (id),
    KEY idx_sinonimos_setor (setor_id),
    CONSTRAINT fk_sinonimos_setor FOREIGN KEY (setor_id) REFERENCES setores (id) ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- "Como faço para..." (N11): fluxos passo a passo.
CREATE TABLE IF NOT EXISTS fluxos (
    id          INT UNSIGNED NOT NULL AUTO_INCREMENT,
    slug        VARCHAR(160) NOT NULL,
    titulo      VARCHAR(200) NOT NULL,
    resumo      VARCHAR(400) NULL,
    setor_id    VARCHAR(60)  NULL,
    canal       ENUM('suap','presencial','ambos') NULL COMMENT 'NULL = não informado',
    prazo       VARCHAR(150) NULL,
    publicado   TINYINT(1)   NOT NULL DEFAULT 1,
    ordem       INT          NOT NULL DEFAULT 0,
    atualizado_em DATETIME   NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_fluxos_slug (slug),
    CONSTRAINT fk_fluxos_setor FOREIGN KEY (setor_id) REFERENCES setores (id) ON UPDATE CASCADE ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS fluxo_passos (
    id        INT UNSIGNED NOT NULL AUTO_INCREMENT,
    fluxo_id  INT UNSIGNED NOT NULL,
    nome      VARCHAR(400) NOT NULL,
    ordem     INT          NOT NULL DEFAULT 0,
    PRIMARY KEY (id),
    KEY idx_passos_fluxo (fluxo_id),
    CONSTRAINT fk_passos_fluxo FOREIGN KEY (fluxo_id) REFERENCES fluxos (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS fluxo_documentos (
    id        INT UNSIGNED NOT NULL AUTO_INCREMENT,
    fluxo_id  INT UNSIGNED NOT NULL,
    nome      VARCHAR(255) NOT NULL,
    ordem     INT          NOT NULL DEFAULT 0,
    PRIMARY KEY (id),
    KEY idx_docs_fluxo (fluxo_id),
    CONSTRAINT fk_docs_fluxo FOREIGN KEY (fluxo_id) REFERENCES fluxos (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

